package com.aux.music.presentation.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/**
 * Enhanced Theme Presets
 * Beautiful, carefully crafted color schemes
 */

// ==================== DARK THEMES ====================

/**
 * Midnight Blue - Deep, professional dark theme
 */
val MidnightBlueColors = darkColorScheme(
    primary = Color(0xFF6B9FFF),
    onPrimary = Color(0xFF002D6B),
    primaryContainer = Color(0xFF004492),
    onPrimaryContainer = Color(0xFFD6E3FF),
    
    secondary = Color(0xFF84CFFF),
    onSecondary = Color(0xFF003548),
    secondaryContainer = Color(0xFF004D67),
    onSecondaryContainer = Color(0xFFBEE9FF),
    
    tertiary = Color(0xFFD6BCFF),
    onTertiary = Color(0xFF3E0072),
    tertiaryContainer = Color(0xFF56239A),
    onTertiaryContainer = Color(0xFFEFDBFF),
    
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    
    background = Color(0xFF0A1120),
    onBackground = Color(0xFFE2E2E9),
    surface = Color(0xFF0A1120),
    onSurface = Color(0xFFE2E2E9),
    
    surfaceVariant = Color(0xFF44464F),
    onSurfaceVariant = Color(0xFFC5C6D0),
    outline = Color(0xFF8F909A)
)

/**
 * Sunset Orange - Warm, vibrant theme
 */
val SunsetOrangeColors = darkColorScheme(
    primary = Color(0xFFFFB870),
    onPrimary = Color(0xFF4A2800),
    primaryContainer = Color(0xFF6A3C00),
    onPrimaryContainer = Color(0xFFFFDDB8),
    
    secondary = Color(0xFFE7BFA5),
    onSecondary = Color(0xFF412C16),
    secondaryContainer = Color(0xFF5A422B),
    onSecondaryContainer = Color(0xFFFFDDBE),
    
    tertiary = Color(0xFFCFC791),
    onTertiary = Color(0xFF363108),
    tertiaryContainer = Color(0xFF4E471D),
    onTertiaryContainer = Color(0xFFECE3AA),
    
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    
    background = Color(0xFF1F1B16),
    onBackground = Color(0xFFEAE1D9),
    surface = Color(0xFF1F1B16),
    onSurface = Color(0xFFEAE1D9),
    
    surfaceVariant = Color(0xFF52443C),
    onSurfaceVariant = Color(0xFFD5C4B5),
    outline = Color(0xFF9E8E81)
)

/**
 * Forest Green - Natural, calming theme
 */
val ForestGreenColors = darkColorScheme(
    primary = Color(0xFF7CDB77),
    onPrimary = Color(0xFF003909),
    primaryContainer = Color(0xFF005313),
    onPrimaryContainer = Color(0xFF98F990),
    
    secondary = Color(0xFFB7CCB1),
    onSecondary = Color(0xFF233424),
    secondaryContainer = Color(0xFF394B39),
    onSecondaryContainer = Color(0xFFD3E8CC),
    
    tertiary = Color(0xFF9FD0CC),
    onTertiary = Color(0xFF00363D),
    tertiaryContainer = Color(0xFF1E4D54),
    onTertiaryContainer = Color(0xFFBBECE8),
    
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    
    background = Color(0xFF101410),
    onBackground = Color(0xFFE0E3DE),
    surface = Color(0xFF101410),
    onSurface = Color(0xFFE0E3DE),
    
    surfaceVariant = Color(0xFF424940),
    onSurfaceVariant = Color(0xFFC2C9BE),
    outline = Color(0xFF8C938A)
)

/**
 * Royal Purple - Elegant, luxurious theme
 */
val RoyalPurpleColors = darkColorScheme(
    primary = Color(0xFFD6BCFF),
    onPrimary = Color(0xFF3E0072),
    primaryContainer = Color(0xFF56239A),
    onPrimaryContainer = Color(0xFFEFDBFF),
    
    secondary = Color(0xFFCCC2DC),
    onSecondary = Color(0xFF332D41),
    secondaryContainer = Color(0xFF4A4458),
    onSecondaryContainer = Color(0xFFE8DEF8),
    
    tertiary = Color(0xFFEFB8C8),
    onTertiary = Color(0xFF4A2532),
    tertiaryContainer = Color(0xFF633B48),
    onTertiaryContainer = Color(0xFFFFD9E3),
    
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    
    background = Color(0xFF1C1B1F),
    onBackground = Color(0xFFE6E1E5),
    surface = Color(0xFF1C1B1F),
    onSurface = Color(0xFFE6E1E5),
    
    surfaceVariant = Color(0xFF49454F),
    onSurfaceVariant = Color(0xFFCAC4D0),
    outline = Color(0xFF938F99)
)

/**
 * Cherry Red - Bold, energetic theme
 */
val CherryRedColors = darkColorScheme(
    primary = Color(0xFFFFB3B5),
    onPrimary = Color(0xFF680015),
    primaryContainer = Color(0xFF920023),
    onPrimaryContainer = Color(0xFFFFDAD7),
    
    secondary = Color(0xFFE6BCBB),
    onSecondary = Color(0xFF44292A),
    secondaryContainer = Color(0xFF5D3F3F),
    onSecondaryContainer = Color(0xFFFFDAD7),
    
    tertiary = Color(0xFFE8C18E),
    onTertiary = Color(0xFF432C06),
    tertiaryContainer = Color(0xFF5C421A),
    onTertiaryContainer = Color(0xFFFFDDB1),
    
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    
    background = Color(0xFF201A19),
    onBackground = Color(0xFFEDE0DE),
    surface = Color(0xFF201A19),
    onSurface = Color(0xFFEDE0DE),
    
    surfaceVariant = Color(0xFF534341),
    onSurfaceVariant = Color(0xFFD8C2BF),
    outline = Color(0xFFA08C8A)
)

/**
 * Ocean Blue - Cool, refreshing theme
 */
val OceanBlueColors = darkColorScheme(
    primary = Color(0xFF5DD4F3),
    onPrimary = Color(0xFF003544),
    primaryContainer = Color(0xFF004D62),
    onPrimaryContainer = Color(0xFFB8EAFF),
    
    secondary = Color(0xFFB3CAD7),
    onSecondary = Color(0xFF1E333C),
    secondaryContainer = Color(0xFF344A53),
    onSecondaryContainer = Color(0xFFCFE6F3),
    
    tertiary = Color(0xFFCBC4E9),
    onTertiary = Color(0xFF332D4D),
    tertiaryContainer = Color(0xFF4A4365),
    onTertiaryContainer = Color(0xFFE8E0FF),
    
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    
    background = Color(0xFF0F1419),
    onBackground = Color(0xFFDFE3E7),
    surface = Color(0xFF0F1419),
    onSurface = Color(0xFFDFE3E7),
    
    surfaceVariant = Color(0xFF40484D),
    onSurfaceVariant = Color(0xFFC0C8CD),
    outline = Color(0xFF8A9297)
)

// ==================== LIGHT THEMES ====================

/**
 * Light Mint - Fresh, clean light theme
 */
val LightMintColors = lightColorScheme(
    primary = Color(0xFF006C51),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFF75F9CF),
    onPrimaryContainer = Color(0xFF002116),
    
    secondary = Color(0xFF4B635A),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFCDE9DC),
    onSecondaryContainer = Color(0xFF072019),
    
    tertiary = Color(0xFF426277),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFC6E7FF),
    onTertiaryContainer = Color(0xFF001E2E),
    
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    
    background = Color(0xFFFAFDFA),
    onBackground = Color(0xFF191C1B),
    surface = Color(0xFFFAFDFA),
    onSurface = Color(0xFF191C1B),
    
    surfaceVariant = Color(0xFFDBE5DF),
    onSurfaceVariant = Color(0xFF404943),
    outline = Color(0xFF707972)
)

/**
 * Light Lavender - Soft, elegant light theme
 */
val LightLavenderColors = lightColorScheme(
    primary = Color(0xFF6750A4),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE9DDFF),
    onPrimaryContainer = Color(0xFF22005D),
    
    secondary = Color(0xFF625B71),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE8DEF8),
    onSecondaryContainer = Color(0xFF1E192B),
    
    tertiary = Color(0xFF7E5260),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFFFD9E3),
    onTertiaryContainer = Color(0xFF31101D),
    
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    
    background = Color(0xFFFFFBFF),
    onBackground = Color(0xFF1C1B1F),
    surface = Color(0xFFFFFBFF),
    onSurface = Color(0xFF1C1B1F),
    
    surfaceVariant = Color(0xFFE7E0EB),
    onSurfaceVariant = Color(0xFF49454E),
    outline = Color(0xFF7A757F)
)

/**
 * Pure OLED Black - True black for OLED screens
 */
val OLEDBlackColors = darkColorScheme(
    primary = Color(0xFF6DB6FF),
    onPrimary = Color(0xFF003258),
    primaryContainer = Color(0xFF00497D),
    onPrimaryContainer = Color(0xFFD0E4FF),
    
    secondary = Color(0xFFBAC9DA),
    onSecondary = Color(0xFF253140),
    secondaryContainer = Color(0xFF3B4858),
    onSecondaryContainer = Color(0xFFD6E5F6),
    
    tertiary = Color(0xFFD5BEE4),
    onTertiary = Color(0xFF3A2948),
    tertiaryContainer = Color(0xFF523F5F),
    onTertiaryContainer = Color(0xFFF2DAFF),
    
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    
    background = Color(0xFF000000), // Pure black
    onBackground = Color(0xFFE3E2E6),
    surface = Color(0xFF000000), // Pure black
    onSurface = Color(0xFFE3E2E6),
    
    surfaceVariant = Color(0xFF43474E),
    onSurfaceVariant = Color(0xFFC3C6CF),
    outline = Color(0xFF8D9199)
)

/**
 * Theme preset data class
 */
data class ThemePreset(
    val name: String,
    val lightColors: androidx.compose.material3.ColorScheme,
    val darkColors: androidx.compose.material3.ColorScheme,
    val description: String
)

/**
 * All available theme presets
 */
val AllThemePresets = listOf(
    ThemePreset(
        name = "Midnight Blue",
        lightColors = androidx.compose.material3.lightColorScheme(),
        darkColors = MidnightBlueColors,
        description = "Deep, professional dark theme"
    ),
    ThemePreset(
        name = "Sunset Orange",
        lightColors = androidx.compose.material3.lightColorScheme(),
        darkColors = SunsetOrangeColors,
        description = "Warm, vibrant theme"
    ),
    ThemePreset(
        name = "Forest Green",
        lightColors = androidx.compose.material3.lightColorScheme(),
        darkColors = ForestGreenColors,
        description = "Natural, calming theme"
    ),
    ThemePreset(
        name = "Royal Purple",
        lightColors = androidx.compose.material3.lightColorScheme(),
        darkColors = RoyalPurpleColors,
        description = "Elegant, luxurious theme"
    ),
    ThemePreset(
        name = "Cherry Red",
        lightColors = androidx.compose.material3.lightColorScheme(),
        darkColors = CherryRedColors,
        description = "Bold, energetic theme"
    ),
    ThemePreset(
        name = "Ocean Blue",
        lightColors = androidx.compose.material3.lightColorScheme(),
        darkColors = OceanBlueColors,
        description = "Cool, refreshing theme"
    ),
    ThemePreset(
        name = "Light Mint",
        lightColors = LightMintColors,
        darkColors = darkColorScheme(),
        description = "Fresh, clean light theme"
    ),
    ThemePreset(
        name = "Light Lavender",
        lightColors = LightLavenderColors,
        darkColors = darkColorScheme(),
        description = "Soft, elegant light theme"
    ),
    ThemePreset(
        name = "OLED Black",
        lightColors = androidx.compose.material3.lightColorScheme(),
        darkColors = OLEDBlackColors,
        description = "Pure black for OLED displays"
    )
)
