package com.aux.music.data.api

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Genius API Integration for Lyrics
 * Docs: https://docs.genius.com/
 */

// Response Models
data class GeniusSearchResponse(
    val response: GeniusResponse
)

data class GeniusResponse(
    val hits: List<GeniusHit>
)

data class GeniusHit(
    val result: GeniusResult
)

data class GeniusResult(
    val id: Long,
    val title: String,
    val primary_artist: GeniusArtist,
    val url: String,
    val path: String
)

data class GeniusArtist(
    val name: String
)

data class GeniusSongResponse(
    val response: GeniusSongData
)

data class GeniusSongData(
    val song: GeniusSongDetail
)

data class GeniusSongDetail(
    val id: Long,
    val title: String,
    val url: String,
    val lyrics_state: String
)

// API Interface
interface GeniusApi {
    @GET("search")
    suspend fun searchSong(
        @Query("q") query: String
    ): GeniusSearchResponse
    
    @GET("songs/{id}")
    suspend fun getSong(
        @Path("id") songId: Long
    ): GeniusSongResponse
}

// Genius Service
object GeniusLyricsService {
    
    private const val BASE_URL = "https://api.genius.com/"
    private var API_KEY = "YOUR_GENIUS_API_KEY_HERE" // Will be replaced
    
    fun setApiKey(apiKey: String) {
        API_KEY = apiKey
    }
    
    private val authInterceptor = Interceptor { chain ->
        val original = chain.request()
        val request = original.newBuilder()
            .header("Authorization", "Bearer $API_KEY")
            .header("User-Agent", "Aux Music Player")
            .build()
        chain.proceed(request)
    }
    
    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .build()
    
    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    
    val api: GeniusApi = retrofit.create(GeniusApi::class.java)
}

// Lyrics Manager
class GeniusLyricsManager {
    
    /**
     * Search for lyrics using artist and title
     */
    suspend fun searchLyrics(artist: String, title: String): String? {
        return try {
            // Search for the song
            val searchQuery = "$artist $title"
            val searchResponse = GeniusLyricsService.api.searchSong(searchQuery)
            
            if (searchResponse.response.hits.isEmpty()) {
                timber.log.Timber.d("No results found for: $searchQuery")
                return null
            }
            
            // Get the first result
            val firstHit = searchResponse.response.hits.first()
            val songUrl = firstHit.result.url
            
            timber.log.Timber.d("Found song: ${firstHit.result.title} by ${firstHit.result.primary_artist.name}")
            timber.log.Timber.d("Song URL: $songUrl")
            
            // Scrape lyrics from the Genius page
            scrapeLyricsFromUrl(songUrl)
            
        } catch (e: Exception) {
            timber.log.Timber.e(e, "Failed to fetch lyrics from Genius")
            null
        }
    }
    
    /**
     * Scrape lyrics from Genius song page
     * Note: Genius API doesn't directly provide lyrics, we need to scrape the webpage
     */
    private suspend fun scrapeLyricsFromUrl(url: String): String? {
        return try {
            // Use JSoup or OkHttp to scrape the page
            val response = okhttp3.OkHttpClient().newCall(
                okhttp3.Request.Builder()
                    .url(url)
                    .build()
            ).execute()
            
            val html = response.body?.string() ?: return null
            
            // Parse HTML to extract lyrics
            // Lyrics are in div with data-lyrics-container attribute
            val lyricsPattern = """data-lyrics-container="true">(.+?)</div>""".toRegex(RegexOption.DOT_MATCHES_ALL)
            val matches = lyricsPattern.findAll(html)
            
            val lyrics = matches.mapNotNull { match ->
                match.groupValues.getOrNull(1)
            }.joinToString("\n\n")
                .replace("<br/>", "\n")
                .replace("<br>", "\n")
                .replace("""<[^>]*>""".toRegex(), "") // Remove HTML tags
                .replace("&quot;", "\"")
                .replace("&amp;", "&")
                .replace("&#x27;", "'")
                .trim()
            
            if (lyrics.isNotEmpty()) {
                timber.log.Timber.d("Successfully scraped lyrics (${lyrics.length} chars)")
                lyrics
            } else {
                timber.log.Timber.w("Lyrics found but empty after parsing")
                null
            }
            
        } catch (e: Exception) {
            timber.log.Timber.e(e, "Failed to scrape lyrics from URL: $url")
            null
        }
    }
    
    /**
     * Get lyrics with retry logic
     */
    suspend fun getLyricsWithRetry(artist: String, title: String, maxRetries: Int = 2): String? {
        repeat(maxRetries) { attempt ->
            val lyrics = searchLyrics(artist, title)
            if (lyrics != null) {
                return lyrics
            }
            
            // Try with simplified search on retry
            if (attempt == 0) {
                // Remove featuring artists, brackets, etc.
                val cleanTitle = title
                    .replace("""\(.*?\)""".toRegex(), "")
                    .replace("""\[.*?\]""".toRegex(), "")
                    .replace("""feat\..*""".toRegex(), "")
                    .replace("""ft\..*""".toRegex(), "")
                    .trim()
                
                val cleanArtist = artist
                    .split(",", "&", "feat", "ft")
                    .firstOrNull()
                    ?.trim() ?: artist
                
                timber.log.Timber.d("Retry with clean search: $cleanArtist - $cleanTitle")
                return searchLyrics(cleanArtist, cleanTitle)
            }
        }
        return null
    }
}

// Extension function for easy use in ViewModel
suspend fun fetchGeniusLyrics(artist: String, title: String): String? {
    return GeniusLyricsManager().getLyricsWithRetry(artist, title)
}
