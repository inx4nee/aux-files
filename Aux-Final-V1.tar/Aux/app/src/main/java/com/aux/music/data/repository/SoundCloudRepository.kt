package com.aux.music.data.repository

import com.aux.music.data.model.SearchResult
import com.aux.music.data.model.Song
import com.aux.music.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * SoundCloud Repository using NewPipe Extractor
 * NewPipe supports both YouTube and SoundCloud!
 */
@Singleton
class SoundCloudRepository @Inject constructor() {

    private val soundCloudService = ServiceList.SoundCloud
    
    // Cache for search results
    private val searchCache = MemoryCache<String, SearchResult>(maxSize = 50)
    
    // Cache for stream URLs (5 min TTL)
    private val streamUrlCache = MemoryCache<String, Pair<String, Long>>(maxSize = 100)
    private val STREAM_CACHE_TTL = 5 * 60 * 1000L

    /**
     * Search for songs on SoundCloud
     */
    suspend fun searchSongs(
        query: String,
        pageToken: String? = null
    ): Resource<SearchResult> = withContext(Dispatchers.IO) {
        try {
            // Check cache
            val cacheKey = "sc-$query-$pageToken"
            searchCache.get(cacheKey)?.let {
                Timber.d("Returning cached SoundCloud results for: $query")
                return@withContext Resource.Success(it)
            }

            withTimeout(30000L) {
                val searchExtractor = soundCloudService.getSearchExtractor(query)
                searchExtractor.fetchPage()

                val songs = searchExtractor.initialPage.items
                    .filterIsInstance<StreamInfoItem>()
                    .filter { 
                        it.streamType == org.schabi.newpipe.extractor.stream.StreamType.AUDIO_STREAM 
                    }
                    .mapNotNull { streamInfoItem ->
                        try {
                            Song(
                                id = streamInfoItem.url.substringAfterLast("/"),
                                title = StringPool.intern(streamInfoItem.name),
                                artist = StringPool.intern(streamInfoItem.uploaderName ?: "Unknown Artist"),
                                duration = streamInfoItem.duration * 1000L,
                                thumbnailUrl = streamInfoItem.thumbnailUrl ?: "",
                                youtubeId = "", // Not applicable for SoundCloud
                                soundCloudId = streamInfoItem.url.substringAfterLast("/"),
                                uploadDate = streamInfoItem.uploadDate?.offsetDateTime()?.toString(),
                                viewCount = streamInfoItem.viewCount,
                                source = MusicSource.SOUNDCLOUD
                            )
                        } catch (e: Exception) {
                            Timber.w(e, "Failed to parse SoundCloud stream item")
                            null
                        }
                    }

                val nextPage = if (searchExtractor.hasNextPage()) {
                    searchExtractor.nextPage?.url
                } else null

                val result = SearchResult(songs = songs, nextPageToken = nextPage)
                searchCache.put(cacheKey, result)
                
                Resource.Success(result)
            }
        } catch (e: java.util.concurrent.TimeoutCancellationException) {
            Timber.e(e, "SoundCloud search timeout for query: $query")
            Resource.Error("Search timeout. Please try again.")
        } catch (e: java.net.UnknownHostException) {
            Timber.e(e, "No internet connection")
            Resource.Error("No internet connection. Please check your network.")
        } catch (e: Exception) {
            Timber.e(e, "SoundCloud search failed for query: $query")
            Resource.Error(ErrorHandler.getErrorMessage(e))
        }
    }

    /**
     * Get stream URL for a SoundCloud track
     */
    suspend fun getStreamUrl(soundCloudId: String): Resource<String> = withContext(Dispatchers.IO) {
        try {
            // Check cache
            streamUrlCache.get(soundCloudId)?.let { (url, timestamp) ->
                if (System.currentTimeMillis() - timestamp < STREAM_CACHE_TTL) {
                    Timber.d("Returning cached SoundCloud stream URL")
                    return@withContext Resource.Success(url)
                } else {
                    streamUrlCache.remove(soundCloudId)
                }
            }

            val streamUrl = retryOperation(times = 3) {
                withTimeout(20000L) {
                    val streamExtractor = soundCloudService.getStreamExtractor(
                        "https://soundcloud.com/$soundCloudId"
                    )
                    streamExtractor.fetchPage()

                    // Get audio stream with best quality
                    val audioStream = streamExtractor.audioStreams
                        .maxByOrNull { it.averageBitrate }
                        ?: throw AuxError.YouTubeError("No audio stream found")

                    audioStream.content ?: throw AuxError.YouTubeError("Stream URL is null")
                }
            }

            streamUrlCache.put(soundCloudId, Pair(streamUrl, System.currentTimeMillis()))
            Resource.Success(streamUrl)
            
        } catch (e: java.util.concurrent.TimeoutCancellationException) {
            Timber.e(e, "SoundCloud stream URL fetch timeout")
            Resource.Error("Request timeout. Please try again.")
        } catch (e: AuxError.YouTubeError) {
            Timber.e(e, "SoundCloud error")
            Resource.Error(e.message)
        } catch (e: Exception) {
            Timber.e(e, "Failed to get SoundCloud stream URL")
            Resource.Error(ErrorHandler.getErrorMessage(e))
        }
    }

    /**
     * Get trending music from SoundCloud
     */
    suspend fun getTrendingMusic(): Resource<List<Song>> = withContext(Dispatchers.IO) {
        try {
            withTimeout(20000L) {
                val kioskExtractor = soundCloudService.getKioskList()
                    .defaultKioskExtractor
                kioskExtractor.fetchPage()

                val songs = kioskExtractor.initialPage.items
                    .filterIsInstance<StreamInfoItem>()
                    .filter { 
                        it.streamType == org.schabi.newpipe.extractor.stream.StreamType.AUDIO_STREAM 
                    }
                    .take(20)
                    .mapNotNull { streamInfoItem ->
                        try {
                            Song(
                                id = streamInfoItem.url.substringAfterLast("/"),
                                title = StringPool.intern(streamInfoItem.name),
                                artist = StringPool.intern(streamInfoItem.uploaderName ?: "Unknown Artist"),
                                duration = streamInfoItem.duration * 1000L,
                                thumbnailUrl = streamInfoItem.thumbnailUrl ?: "",
                                youtubeId = "",
                                soundCloudId = streamInfoItem.url.substringAfterLast("/"),
                                uploadDate = streamInfoItem.uploadDate?.offsetDateTime()?.toString(),
                                viewCount = streamInfoItem.viewCount,
                                source = MusicSource.SOUNDCLOUD
                            )
                        } catch (e: Exception) {
                            Timber.w(e, "Failed to parse SoundCloud trending item")
                            null
                        }
                    }

                Resource.Success(songs)
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to get SoundCloud trending music")
            Resource.Error(ErrorHandler.getErrorMessage(e))
        }
    }

    /**
     * Clear cache
     */
    fun clearCache() {
        searchCache.clear()
        streamUrlCache.clear()
        Timber.d("Cleared SoundCloud repository caches")
    }
}

/**
 * Enum for music sources
 */
enum class MusicSource {
    YOUTUBE,
    SOUNDCLOUD
}
