package com.aux.music.data.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import timber.log.Timber
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for fetching song lyrics from free APIs
 */
@Singleton
class LyricsRepository @Inject constructor() {

    private val client = OkHttpClient()

    /**
     * Fetch lyrics using free lyrics.ovh API
     * No API key required!
     */
    suspend fun getLyrics(artist: String, title: String): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                // Clean up artist and title
                val cleanArtist = artist.replace(Regex("[^a-zA-Z0-9 ]"), "").trim()
                val cleanTitle = title.replace(Regex("[^a-zA-Z0-9 ]"), "").trim()
                
                // Try lyrics.ovh (free, no key needed)
                val lyricsOvhResult = fetchFromLyricsOvh(cleanArtist, cleanTitle)
                if (lyricsOvhResult != null) {
                    return@withContext Result.success(lyricsOvhResult)
                }

                // Fallback: Try lyricsfreakAPI
                val lyricsFreakResult = fetchFromLyricsFreak(cleanArtist, cleanTitle)
                if (lyricsFreakResult != null) {
                    return@withContext Result.success(lyricsFreakResult)
                }

                Result.failure(Exception("Lyrics not found"))
            } catch (e: Exception) {
                Timber.e(e, "Failed to fetch lyrics")
                Result.failure(e)
            }
        }
    }

    /**
     * Fetch from lyrics.ovh API (Free, no key needed)
     */
    private fun fetchFromLyricsOvh(artist: String, title: String): String? {
        return try {
            val url = "https://api.lyrics.ovh/v1/${URLEncoder.encode(artist, "UTF-8")}/${URLEncoder.encode(title, "UTF-8")}"
            
            val request = Request.Builder()
                .url(url)
                .build()

            val response = client.newCall(request).execute()
            
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "")
                val lyrics = json.optString("lyrics")
                if (lyrics.isNotBlank()) {
                    Timber.d("Lyrics found from lyrics.ovh")
                    lyrics
                } else null
            } else null
        } catch (e: Exception) {
            Timber.w(e, "lyrics.ovh failed")
            null
        }
    }

    /**
     * Fetch from lyricsfreak API (Alternative free API)
     */
    private fun fetchFromLyricsFreak(artist: String, title: String): String? {
        return try {
            // Simple scraping approach - parse HTML
            val searchQuery = "${artist} ${title} lyrics"
            val url = "https://www.azlyrics.com/lyrics/${artist.lowercase().replace(" ", "")}/${title.lowercase().replace(" ", "")}.html"
            
            val request = Request.Builder()
                .url(url)
                .addHeader("User-Agent", "Mozilla/5.0")
                .build()

            val response = client.newCall(request).execute()
            
            if (response.isSuccessful) {
                val html = response.body?.string() ?: ""
                
                // Extract lyrics from HTML (simplified)
                val lyricsStart = html.indexOf("<!-- Usage of azlyrics.com content")
                val lyricsEnd = html.indexOf("</div>", lyricsStart)
                
                if (lyricsStart != -1 && lyricsEnd != -1) {
                    val lyricsHtml = html.substring(lyricsStart, lyricsEnd)
                    val lyrics = lyricsHtml
                        .replace(Regex("<[^>]*>"), "")
                        .replace("&quot;", "\"")
                        .replace("&amp;", "&")
                        .trim()
                    
                    if (lyrics.isNotBlank()) {
                        Timber.d("Lyrics found from scraping")
                        lyrics
                    } else null
                } else null
            } else null
        } catch (e: Exception) {
            Timber.w(e, "Scraping failed")
            null
        }
    }

    /**
     * Parse LRC format lyrics (for synchronized lyrics)
     * Format: [mm:ss.xx]lyric text
     */
    fun parseLRC(lrcContent: String): List<LyricLine> {
        val lines = mutableListOf<LyricLine>()
        val pattern = Regex("\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})](.*)") 

        lrcContent.lines().forEach { line ->
            pattern.matchEntire(line)?.let { match ->
                val (minutes, seconds, milliseconds, text) = match.destructured
                
                val timestamp = (minutes.toInt() * 60 + seconds.toInt()) * 1000L +
                              milliseconds.padEnd(3, '0').take(3).toInt()
                
                if (text.trim().isNotEmpty()) {
                    lines.add(LyricLine(timestamp, text.trim()))
                }
            }
        }

        return lines.sortedBy { it.timestamp }
    }

    /**
     * Search for synchronized lyrics (LRC format)
     * Uses lrclib.net - free API for synced lyrics
     */
    suspend fun getSyncedLyrics(artist: String, title: String): Result<List<LyricLine>> {
        return withContext(Dispatchers.IO) {
            try {
                val url = "https://lrclib.net/api/get?" +
                        "artist_name=${URLEncoder.encode(artist, "UTF-8")}&" +
                        "track_name=${URLEncoder.encode(title, "UTF-8")}"

                val request = Request.Builder()
                    .url(url)
                    .build()

                val response = client.newCall(request).execute()

                if (response.isSuccessful) {
                    val json = JSONObject(response.body?.string() ?: "")
                    val syncedLyrics = json.optString("syncedLyrics")
                    
                    if (syncedLyrics.isNotBlank()) {
                        val lines = parseLRC(syncedLyrics)
                        Timber.d("Synced lyrics found: ${lines.size} lines")
                        Result.success(lines)
                    } else {
                        // Try plain lyrics if synced not available
                        val plainLyrics = json.optString("plainLyrics")
                        if (plainLyrics.isNotBlank()) {
                            // Convert plain lyrics to simple lines without timestamps
                            val lines = plainLyrics.lines().mapIndexed { index, text ->
                                LyricLine(index * 3000L, text) // 3 seconds per line
                            }
                            Result.success(lines)
                        } else {
                            Result.failure(Exception("No lyrics found"))
                        }
                    }
                } else {
                    Result.failure(Exception("API request failed"))
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to fetch synced lyrics")
                Result.failure(e)
            }
        }
    }
}

/**
 * Lyric line with timestamp for synchronized lyrics
 */
data class LyricLine(
    val timestamp: Long, // milliseconds
    val text: String
)
