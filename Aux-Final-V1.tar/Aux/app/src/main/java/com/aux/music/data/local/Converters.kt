package com.aux.music.data.local

import androidx.room.TypeConverter
import com.aux.music.data.model.DownloadStatus

/**
 * Type converters for Room Database
 */
class Converters {
    
    @TypeConverter
    fun fromDownloadStatus(status: DownloadStatus): String {
        return status.name
    }

    @TypeConverter
    fun toDownloadStatus(value: String): DownloadStatus {
        return DownloadStatus.valueOf(value)
    }
}
