package com.aux.music.presentation.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

/**
 * Music Source Switcher Component
 * Allows switching between YouTube and SoundCloud
 */
@Composable
fun SourceSwitcher(
    currentSource: MusicSource,
    onSourceChange: (MusicSource) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // YouTube Button
            SourceButton(
                icon = Icons.Default.PlayArrow, // YouTube icon
                label = "YouTube",
                isSelected = currentSource == MusicSource.YOUTUBE,
                onClick = { onSourceChange(MusicSource.YOUTUBE) },
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(8.dp))

            // SoundCloud Button
            SourceButton(
                icon = Icons.Default.CloudQueue, // SoundCloud icon
                label = "SoundCloud",
                isSelected = currentSource == MusicSource.SOUNDCLOUD,
                onClick = { onSourceChange(MusicSource.SOUNDCLOUD) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SourceButton(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val containerColor = if (isSelected) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }

    val contentColor = if (isSelected) {
        MaterialTheme.colorScheme.onPrimary
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Button(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        contentPadding = PaddingValues(horizontal = 12.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

/**
 * Compact Source Switcher (for top bar)
 */
@Composable
fun CompactSourceSwitcher(
    currentSource: MusicSource,
    onSourceChange: (MusicSource) -> Unit,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        IconButton(onClick = { showMenu = true }) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AnimatedContent(
                    targetState = currentSource,
                    transitionSpec = {
                        (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                            slideOutHorizontally { width -> -width } + fadeOut()
                        ).using(SizeTransform(clip = false))
                    },
                    label = "source_animation"
                ) { source ->
                    Icon(
                        imageVector = when (source) {
                            MusicSource.YOUTUBE -> Icons.Default.PlayArrow
                            MusicSource.SOUNDCLOUD -> Icons.Default.CloudQueue
                        },
                        contentDescription = when (source) {
                            MusicSource.YOUTUBE -> "YouTube"
                            MusicSource.SOUNDCLOUD -> "SoundCloud"
                        }
                    )
                }
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = "Switch Source",
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false }
        ) {
            DropdownMenuItem(
                text = {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PlayArrow, "YouTube")
                        Text("YouTube")
                        if (currentSource == MusicSource.YOUTUBE) {
                            Icon(
                                Icons.Default.Check,
                                "Selected",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                onClick = {
                    onSourceChange(MusicSource.YOUTUBE)
                    showMenu = false
                }
            )
            
            DropdownMenuItem(
                text = {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CloudQueue, "SoundCloud")
                        Text("SoundCloud")
                        if (currentSource == MusicSource.SOUNDCLOUD) {
                            Icon(
                                Icons.Default.Check,
                                "Selected",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                onClick = {
                    onSourceChange(MusicSource.SOUNDCLOUD)
                    showMenu = false
                }
            )
        }
    }
}

/**
 * Source Indicator Chip
 */
@Composable
fun SourceIndicatorChip(
    source: MusicSource,
    modifier: Modifier = Modifier
) {
    AssistChip(
        onClick = { },
        label = {
            Text(
                text = when (source) {
                    MusicSource.YOUTUBE -> "YouTube"
                    MusicSource.SOUNDCLOUD -> "SoundCloud"
                },
                style = MaterialTheme.typography.labelSmall
            )
        },
        leadingIcon = {
            Icon(
                imageVector = when (source) {
                    MusicSource.YOUTUBE -> Icons.Default.PlayArrow
                    MusicSource.SOUNDCLOUD -> Icons.Default.CloudQueue
                },
                contentDescription = null,
                modifier = Modifier.size(16.dp)
            )
        },
        modifier = modifier
    )
}
