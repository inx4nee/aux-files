package com.aux.music.util

/**
 * App-wide constants
 */
object Constants {
    // App Info
    const val APP_NAME = "Aux"
    const val APP_VERSION = "1.0.0"
    const val DEVELOPER_NAME = "Kamui Hub"
    
    // Links
    const val GITHUB_URL = "https://github.com/inx4nee"
    const val BUY_ME_A_COFFEE_URL = "https://buymeacoffee.com/Sainnee"
    
    // Database
    const val DATABASE_NAME = "aux_database"
    const val DATABASE_VERSION = 1
    
    // Preferences
    const val PREFS_NAME = "aux_preferences"
    const val KEY_THEME = "theme"
    const val KEY_ACCENT_COLOR = "accent_color"
    const val KEY_MUSIC_SOURCE = "music_source"
    const val KEY_DEFAULT_QUALITY = "default_quality"
    
    // Cache
    const val MAX_CACHE_SIZE = 500 * 1024 * 1024L // 500 MB
    const val STREAM_URL_CACHE_TTL = 5 * 60 * 1000L // 5 minutes
    
    // Support Dialog
    const val SUPPORT_DIALOG_SHOW_AFTER_OPENS = 100 // Show after 100 app opens
    const val SUPPORT_DIALOG_INTERVAL_DAYS = 30 // Show again after 30 days
    const val SUPPORT_DIALOG_MAX_TIMES = 2 // Show maximum 2 times
}
