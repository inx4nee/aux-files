# 🚀 Quick Start Guide

Get Aux Music Player running in 5 minutes!

---

## ⚡ Super Fast Setup

### **1. Open Project (2 minutes)**
```
1. Open Android Studio
2. File → Open
3. Select Aux folder
4. Wait for Gradle sync
```

### **2. Add Icon (30 seconds) - OPTIONAL**
```
1. Right-click res folder
2. New → Image Asset
3. Select your icon PNG
4. Click Finish
```

### **3. Build & Run (2 minutes)**
```
1. Connect device/emulator
2. Click ▶️ button
3. Wait for build
4. App launches!
```

**DONE! App is running!** 🎉

---

## 🎯 First Time Setup

After app launches:

### **1. Try These Features:**
- 🔍 Search for "rock music"
- ▶️ Play a song
- ⚙️ Tap controls icon to adjust speed
- 🎨 Settings → Themes → Try different themes
- ☁️ Search screen → Switch to SoundCloud

### **2. Test Support Dialog:**
Want to test the donation popup quickly?

**In `util/Constants.kt`, temporarily change:**
```kotlin
const val SUPPORT_DIALOG_SHOW_AFTER_OPENS = 3  // Show after 3 opens (testing)
```

Then open/close app 3 times → Dialog appears!

**Remember to change back to 100 before release!**

---

## 🔧 Troubleshooting

### **Gradle Sync Failed?**
```
File → Invalidate Caches → Restart
```

### **Dependencies Error?**
```
Check internet connection
File → Sync Project with Gradle Files
```

### **Build Failed?**
```
Verify:
- JDK 17+ installed
- Android SDK 34 installed
- Internet connection active
```

### **Won't Install?**
```
On device:
Settings → Developer Options → Enable USB Debugging
Accept ADB permissions
```

---

## 📱 Test These Features

### **Must-Try Features:**
1. ⚡ **Speed Control** - Now Playing → ⚙️ → Adjust speed
2. 🔊 **Audio Effects** - Same dialog → Bass/3D/Reverb sliders
3. 🎨 **Themes** - Settings → Themes → Try all 8!
4. ☁️ **SoundCloud** - Search → Tap source switcher at top
5. ⏱️ **Sleep Timer** - Now Playing → Timer icon
6. 📊 **Statistics** - Settings → Statistics (after playing songs)
7. 🎵 **Lyrics** - Play song → Lyrics button
8. 📋 **Queue** - Now Playing → Queue icon

---

## ⏱️ Expected Times

**First Build:**
- Gradle sync: 5-10 minutes
- First compile: 2-3 minutes
- Install: 30 seconds
- **Total: ~10 minutes**

**Subsequent Builds:**
- Compile: 30-60 seconds
- Install: 10 seconds
- **Total: ~1 minute**

---

## ✅ What's Working

After building, these work immediately:

✅ YouTube streaming
✅ SoundCloud streaming
✅ All 23+ features
✅ All UI screens
✅ Database
✅ Navigation
✅ Themes
✅ Everything!

---

## 🎯 Your Links Are Active

- **Buy Me a Coffee:** Opens after 100 app uses (or manually in About/Settings)
- **GitHub:** Linked in About dialog
- **Studio:** Kamui Hub shown throughout app

---

## 🚀 You're Ready!

**That's it!** Your app is built and running.

Now you can:
- ✅ Use it yourself
- ✅ Share with friends
- ✅ Publish to Play Store
- ✅ Customize further

---

## 📚 Need More Help?

See `/Aux-Documentation/` folder for:
- Complete feature guides
- Detailed setup instructions
- Customization options
- Technical documentation

---

**Happy coding!** 🎵✨

© 2025 Kamui Hub
