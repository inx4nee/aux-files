package com.aux.music.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aux.music.data.model.Song
import com.aux.music.data.repository.MusicRepository
import com.aux.music.data.repository.YouTubeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for search functionality
 */
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val youTubeRepository: YouTubeRepository,
    private val musicRepository: MusicRepository
) : ViewModel() {

    private val _searchResults = MutableStateFlow<List<Song>>(emptyList())
    val searchResults: StateFlow<List<Song>> = _searchResults.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private var currentQuery: String = ""

    fun searchSongs(query: String) {
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }

        currentQuery = query
        _isLoading.value = true
        _error.value = null

        viewModelScope.launch {
            val result = youTubeRepository.searchSongs(query)
            result.onSuccess { searchResult ->
                _searchResults.value = searchResult.songs
                _isLoading.value = false
            }.onFailure { exception ->
                _error.value = exception.message ?: "Search failed"
                _isLoading.value = false
            }
        }
    }

    fun clearSearch() {
        _searchResults.value = emptyList()
        currentQuery = ""
        _error.value = null
    }

    fun addSongToLibrary(song: Song) {
        viewModelScope.launch {
            musicRepository.insertSong(song)
        }
    }
}
