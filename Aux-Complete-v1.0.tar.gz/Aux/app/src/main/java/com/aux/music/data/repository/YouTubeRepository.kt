package com.aux.music.data.repository

import com.aux.music.data.model.SearchResult
import com.aux.music.data.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for YouTube music operations using NewPipe Extractor
 */
@Singleton
class YouTubeRepository @Inject constructor() {

    private val youtubeService = ServiceList.YouTube

    /**
     * Search for songs on YouTube
     */
    suspend fun searchSongs(query: String, pageToken: String? = null): Result<SearchResult> =
        withContext(Dispatchers.IO) {
            try {
                val searchExtractor = youtubeService.getSearchExtractor(query)
                
                if (pageToken != null) {
                    searchExtractor.fetchPage()
                } else {
                    searchExtractor.fetchPage()
                }

                val songs = searchExtractor.initialPage.items
                    .filterIsInstance<StreamInfoItem>()
                    .filter { it.streamType == org.schabi.newpipe.extractor.stream.StreamType.AUDIO_STREAM || 
                              it.streamType == org.schabi.newpipe.extractor.stream.StreamType.VIDEO_STREAM }
                    .map { streamInfoItem ->
                        Song(
                            id = streamInfoItem.url.substringAfterLast("="),
                            title = streamInfoItem.name,
                            artist = streamInfoItem.uploaderName ?: "Unknown Artist",
                            duration = streamInfoItem.duration * 1000L, // Convert to milliseconds
                            thumbnailUrl = streamInfoItem.thumbnailUrl ?: "",
                            youtubeId = streamInfoItem.url.substringAfterLast("="),
                            uploadDate = streamInfoItem.uploadDate?.offsetDateTime()?.toString(),
                            viewCount = streamInfoItem.viewCount
                        )
                    }

                val nextPage = if (searchExtractor.hasNextPage()) {
                    searchExtractor.nextPage?.url
                } else null

                Result.success(SearchResult(songs = songs, nextPageToken = nextPage))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    /**
     * Get stream URL for a song
     */
    suspend fun getStreamUrl(youtubeId: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val streamExtractor = youtubeService.getStreamExtractor("https://www.youtube.com/watch?v=$youtubeId")
            streamExtractor.fetchPage()

            // Get audio stream with best quality
            val audioStream = streamExtractor.audioStreams
                .maxByOrNull { it.averageBitrate }

            val streamUrl = audioStream?.content ?: throw Exception("No audio stream found")
            Result.success(streamUrl)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Get detailed song information
     */
    suspend fun getSongDetails(youtubeId: String): Result<Song> = withContext(Dispatchers.IO) {
        try {
            val streamExtractor = youtubeService.getStreamExtractor("https://www.youtube.com/watch?v=$youtubeId")
            streamExtractor.fetchPage()

            val song = Song(
                id = youtubeId,
                title = streamExtractor.name,
                artist = streamExtractor.uploaderName ?: "Unknown Artist",
                duration = streamExtractor.length * 1000L,
                thumbnailUrl = streamExtractor.thumbnailUrl ?: "",
                youtubeId = youtubeId,
                uploadDate = streamExtractor.uploadDate?.offsetDateTime()?.toString(),
                viewCount = streamExtractor.viewCount
            )

            Result.success(song)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Get trending music
     */
    suspend fun getTrendingMusic(): Result<List<Song>> = withContext(Dispatchers.IO) {
        try {
            val kioskExtractor = youtubeService.getKioskList().getExtractorById("Trending", null)
            kioskExtractor.fetchPage()

            val songs = kioskExtractor.initialPage.items
                .filterIsInstance<StreamInfoItem>()
                .filter { it.streamType == org.schabi.newpipe.extractor.stream.StreamType.AUDIO_STREAM || 
                          it.streamType == org.schabi.newpipe.extractor.stream.StreamType.VIDEO_STREAM }
                .take(20) // Limit to 20 items
                .map { streamInfoItem ->
                    Song(
                        id = streamInfoItem.url.substringAfterLast("="),
                        title = streamInfoItem.name,
                        artist = streamInfoItem.uploaderName ?: "Unknown Artist",
                        duration = streamInfoItem.duration * 1000L,
                        thumbnailUrl = streamInfoItem.thumbnailUrl ?: "",
                        youtubeId = streamInfoItem.url.substringAfterLast("="),
                        uploadDate = streamInfoItem.uploadDate?.offsetDateTime()?.toString(),
                        viewCount = streamInfoItem.viewCount
                    )
                }

            Result.success(songs)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
