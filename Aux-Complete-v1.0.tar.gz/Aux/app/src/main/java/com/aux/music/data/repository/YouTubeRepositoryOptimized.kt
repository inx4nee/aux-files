package com.aux.music.data.repository

import com.aux.music.data.model.SearchResult
import com.aux.music.data.model.Song
import com.aux.music.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Optimized Repository for YouTube music operations with error handling
 */
@Singleton
class YouTubeRepositoryOptimized @Inject constructor() {

    private val youtubeService = ServiceList.YouTube
    
    // Cache for search results to reduce API calls
    private val searchCache = MemoryCache<String, SearchResult>(maxSize = 50)
    
    // Cache for stream URLs (short TTL)
    private val streamUrlCache = MemoryCache<String, Pair<String, Long>>(maxSize = 100)
    private val STREAM_CACHE_TTL = 5 * 60 * 1000L // 5 minutes

    /**
     * Search for songs on YouTube with error handling and caching
     */
    suspend fun searchSongs(
        query: String, 
        pageToken: String? = null
    ): Resource<SearchResult> = withContext(Dispatchers.IO) {
        try {
            // Check cache first
            val cacheKey = "$query-$pageToken"
            searchCache.get(cacheKey)?.let {
                Timber.d("Returning cached search results for: $query")
                return@withContext Resource.Success(it)
            }

            // Timeout after 30 seconds
            withTimeout(30000L) {
                val searchExtractor = youtubeService.getSearchExtractor(query)
                
                if (pageToken != null) {
                    searchExtractor.fetchPage()
                } else {
                    searchExtractor.fetchPage()
                }

                val songs = searchExtractor.initialPage.items
                    .filterIsInstance<StreamInfoItem>()
                    .filter { 
                        it.streamType == org.schabi.newpipe.extractor.stream.StreamType.AUDIO_STREAM || 
                        it.streamType == org.schabi.newpipe.extractor.stream.StreamType.VIDEO_STREAM 
                    }
                    .mapNotNull { streamInfoItem ->
                        try {
                            Song(
                                id = streamInfoItem.url.substringAfterLast("="),
                                title = StringPool.intern(streamInfoItem.name),
                                artist = StringPool.intern(streamInfoItem.uploaderName ?: "Unknown Artist"),
                                duration = streamInfoItem.duration * 1000L,
                                thumbnailUrl = streamInfoItem.thumbnailUrl ?: "",
                                youtubeId = streamInfoItem.url.substringAfterLast("="),
                                uploadDate = streamInfoItem.uploadDate?.offsetDateTime()?.toString(),
                                viewCount = streamInfoItem.viewCount
                            )
                        } catch (e: Exception) {
                            Timber.w(e, "Failed to parse stream item")
                            null
                        }
                    }

                val nextPage = if (searchExtractor.hasNextPage()) {
                    searchExtractor.nextPage?.url
                } else null

                val result = SearchResult(songs = songs, nextPageToken = nextPage)
                
                // Cache the result
                searchCache.put(cacheKey, result)
                
                Resource.Success(result)
            }
        } catch (e: java.util.concurrent.TimeoutCancellationException) {
            Timber.e(e, "Search timeout for query: $query")
            Resource.Error("Search timeout. Please try again.")
        } catch (e: java.net.UnknownHostException) {
            Timber.e(e, "No internet connection")
            Resource.Error("No internet connection. Please check your network.")
        } catch (e: Exception) {
            Timber.e(e, "Search failed for query: $query")
            Resource.Error(ErrorHandler.getErrorMessage(e))
        }
    }

    /**
     * Get stream URL for a song with caching and retry logic
     */
    suspend fun getStreamUrl(youtubeId: String): Resource<String> = withContext(Dispatchers.IO) {
        try {
            // Check cache with TTL
            streamUrlCache.get(youtubeId)?.let { (url, timestamp) ->
                if (System.currentTimeMillis() - timestamp < STREAM_CACHE_TTL) {
                    Timber.d("Returning cached stream URL for: $youtubeId")
                    return@withContext Resource.Success(url)
                } else {
                    streamUrlCache.remove(youtubeId)
                }
            }

            // Retry up to 3 times with exponential backoff
            val streamUrl = retryOperation(times = 3) {
                withTimeout(20000L) {
                    val streamExtractor = youtubeService.getStreamExtractor(
                        "https://www.youtube.com/watch?v=$youtubeId"
                    )
                    streamExtractor.fetchPage()

                    // Get audio stream with best quality
                    val audioStream = streamExtractor.audioStreams
                        .maxByOrNull { it.averageBitrate }
                        ?: throw AuxError.YouTubeError("No audio stream found")

                    audioStream.content ?: throw AuxError.YouTubeError("Stream URL is null")
                }
            }

            // Cache the URL with timestamp
            streamUrlCache.put(youtubeId, Pair(streamUrl, System.currentTimeMillis()))
            
            Resource.Success(streamUrl)
        } catch (e: java.util.concurrent.TimeoutCancellationException) {
            Timber.e(e, "Stream URL fetch timeout for: $youtubeId")
            Resource.Error("Request timeout. Please try again.")
        } catch (e: AuxError.YouTubeError) {
            Timber.e(e, "YouTube error for: $youtubeId")
            Resource.Error(e.message)
        } catch (e: Exception) {
            Timber.e(e, "Failed to get stream URL for: $youtubeId")
            Resource.Error(ErrorHandler.getErrorMessage(e))
        }
    }

    /**
     * Get detailed song information with error handling
     */
    suspend fun getSongDetails(youtubeId: String): Resource<Song> = withContext(Dispatchers.IO) {
        try {
            withTimeout(15000L) {
                val streamExtractor = youtubeService.getStreamExtractor(
                    "https://www.youtube.com/watch?v=$youtubeId"
                )
                streamExtractor.fetchPage()

                val song = Song(
                    id = youtubeId,
                    title = StringPool.intern(streamExtractor.name),
                    artist = StringPool.intern(streamExtractor.uploaderName ?: "Unknown Artist"),
                    duration = streamExtractor.length * 1000L,
                    thumbnailUrl = streamExtractor.thumbnailUrl ?: "",
                    youtubeId = youtubeId,
                    uploadDate = streamExtractor.uploadDate?.offsetDateTime()?.toString(),
                    viewCount = streamExtractor.viewCount
                )

                Resource.Success(song)
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to get song details for: $youtubeId")
            Resource.Error(ErrorHandler.getErrorMessage(e))
        }
    }

    /**
     * Get trending music with error handling
     */
    suspend fun getTrendingMusic(): Resource<List<Song>> = withContext(Dispatchers.IO) {
        try {
            withTimeout(20000L) {
                val kioskExtractor = youtubeService.getKioskList()
                    .getExtractorById("Trending", null)
                kioskExtractor.fetchPage()

                val songs = kioskExtractor.initialPage.items
                    .filterIsInstance<StreamInfoItem>()
                    .filter { 
                        it.streamType == org.schabi.newpipe.extractor.stream.StreamType.AUDIO_STREAM || 
                        it.streamType == org.schabi.newpipe.extractor.stream.StreamType.VIDEO_STREAM 
                    }
                    .take(20)
                    .mapNotNull { streamInfoItem ->
                        try {
                            Song(
                                id = streamInfoItem.url.substringAfterLast("="),
                                title = StringPool.intern(streamInfoItem.name),
                                artist = StringPool.intern(streamInfoItem.uploaderName ?: "Unknown Artist"),
                                duration = streamInfoItem.duration * 1000L,
                                thumbnailUrl = streamInfoItem.thumbnailUrl ?: "",
                                youtubeId = streamInfoItem.url.substringAfterLast("="),
                                uploadDate = streamInfoItem.uploadDate?.offsetDateTime()?.toString(),
                                viewCount = streamInfoItem.viewCount
                            )
                        } catch (e: Exception) {
                            Timber.w(e, "Failed to parse trending item")
                            null
                        }
                    }

                Resource.Success(songs)
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to get trending music")
            Resource.Error(ErrorHandler.getErrorMessage(e))
        }
    }

    /**
     * Clear all caches
     */
    fun clearCache() {
        searchCache.clear()
        streamUrlCache.clear()
        Timber.d("Cleared YouTube repository caches")
    }

    /**
     * Get cache statistics
     */
    fun getCacheStats(): Pair<Int, Int> {
        return Pair(searchCache.size(), streamUrlCache.size())
    }
}
