package com.aux.music.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Settings Screen for app preferences
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBackClick: () -> Unit = {}
) {
    var darkModeEnabled by remember { mutableStateOf(false) }
    var downloadQuality by remember { mutableStateOf("High") }
    var autoDownload by remember { mutableStateOf(false) }
    var notificationsEnabled by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Appearance Section
            item {
                Text(
                    text = "Appearance",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
            
            item {
                SettingItem(
                    icon = Icons.Default.DarkMode,
                    title = "Dark Mode",
                    description = "Use dark theme (follows system default)",
                    trailing = {
                        Switch(
                            checked = darkModeEnabled,
                            onCheckedChange = { darkModeEnabled = it }
                        )
                    }
                )
            }

            // Download Section
            item {
                Text(
                    text = "Downloads",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(vertical = 8.dp, top = 16.dp)
                )
            }

            item {
                SettingItem(
                    icon = Icons.Default.HighQuality,
                    title = "Download Quality",
                    description = "Audio quality for downloads: $downloadQuality",
                    onClick = { /* TODO: Show quality picker */ }
                )
            }

            item {
                SettingItem(
                    icon = Icons.Default.CloudDownload,
                    title = "Auto Download",
                    description = "Automatically download played songs",
                    trailing = {
                        Switch(
                            checked = autoDownload,
                            onCheckedChange = { autoDownload = it }
                        )
                    }
                )
            }

            // Playback Section
            item {
                Text(
                    text = "Playback",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(vertical = 8.dp, top = 16.dp)
                )
            }

            item {
                SettingItem(
                    icon = Icons.Default.Notifications,
                    title = "Notifications",
                    description = "Show playback notifications",
                    trailing = {
                        Switch(
                            checked = notificationsEnabled,
                            onCheckedChange = { notificationsEnabled = it }
                        )
                    }
                )
            }

            // Storage Section
            item {
                Text(
                    text = "Storage",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(vertical = 8.dp, top = 16.dp)
                )
            }

            item {
                SettingItem(
                    icon = Icons.Default.Storage,
                    title = "Clear Cache",
                    description = "Free up space by clearing cached data",
                    onClick = { /* TODO: Clear cache */ }
                )
            }

            item {
                SettingItem(
                    icon = Icons.Default.Delete,
                    title = "Clear All Data",
                    description = "Remove all songs, playlists, and downloads",
                    onClick = { /* TODO: Clear all data with confirmation */ },
                    tint = MaterialTheme.colorScheme.error
                )
            }

            // About Section
            item {
                Text(
                    text = "About",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(vertical = 8.dp, top = 16.dp)
                )
            }

            item {
                SettingItem(
                    icon = Icons.Default.Info,
                    title = "Version",
                    description = "1.0.0"
                )
            }

            item {
                SettingItem(
                    icon = Icons.Default.Business,
                    title = "Studio",
                    description = "Kamui Hub"
                )
            }

            item {
                SettingItem(
                    icon = Icons.Default.Code,
                    title = "Developer",
                    description = "github.com/inx4nee",
                    onClick = { /* TODO: Open GitHub */ }
                )
            }
        }
    }
}

@Composable
fun SettingItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    onClick: (() -> Unit)? = null,
    trailing: @Composable (() -> Unit)? = null,
    tint: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (onClick != null) {
                    Modifier.clickable(onClick = onClick)
                } else {
                    Modifier
                }
            ),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(24.dp)
                )

                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = tint
                    )
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            trailing?.invoke()
        }
    }
}
