package com.aux.music.util

import android.content.Context
import android.widget.Toast
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import timber.log.Timber

/**
 * Sealed class representing different states of a resource
 */
sealed class Resource<T>(
    val data: T? = null,
    val message: String? = null
) {
    class Success<T>(data: T) : Resource<T>(data)
    class Error<T>(message: String, data: T? = null) : Resource<T>(data, message)
    class Loading<T>(data: T? = null) : Resource<T>(data)
}

/**
 * Error types for better error handling
 */
sealed class AuxError(val message: String, val throwable: Throwable? = null) {
    class NetworkError(message: String = "No internet connection", throwable: Throwable? = null) : 
        AuxError(message, throwable)
    
    class YouTubeError(message: String = "Failed to fetch from YouTube", throwable: Throwable? = null) : 
        AuxError(message, throwable)
    
    class DatabaseError(message: String = "Database operation failed", throwable: Throwable? = null) : 
        AuxError(message, throwable)
    
    class PlaybackError(message: String = "Playback error occurred", throwable: Throwable? = null) : 
        AuxError(message, throwable)
    
    class DownloadError(message: String = "Download failed", throwable: Throwable? = null) : 
        AuxError(message, throwable)
    
    class PermissionError(message: String = "Permission denied", throwable: Throwable? = null) : 
        AuxError(message, throwable)
    
    class StorageError(message: String = "Insufficient storage", throwable: Throwable? = null) : 
        AuxError(message, throwable)
    
    class UnknownError(message: String = "An unknown error occurred", throwable: Throwable? = null) : 
        AuxError(message, throwable)
}

/**
 * Extension function to handle errors in Flow
 */
fun <T> Flow<T>.asResource(): Flow<Resource<T>> {
    return this
        .map<T, Resource<T>> { Resource.Success(it) }
        .onStart { emit(Resource.Loading()) }
        .catch { throwable ->
            emit(Resource.Error(throwable.localizedMessage ?: "Unknown error occurred"))
            Timber.e(throwable)
        }
}

/**
 * Safe API call wrapper
 */
suspend fun <T> safeApiCall(
    apiCall: suspend () -> T
): Resource<T> {
    return try {
        Resource.Success(apiCall())
    } catch (e: Exception) {
        Timber.e(e)
        when (e) {
            is java.net.UnknownHostException -> 
                Resource.Error("No internet connection")
            is java.net.SocketTimeoutException -> 
                Resource.Error("Connection timeout")
            is retrofit2.HttpException -> 
                Resource.Error("Server error: ${e.code()}")
            else -> 
                Resource.Error(e.localizedMessage ?: "Unknown error occurred")
        }
    }
}

/**
 * Safe database operation wrapper
 */
suspend fun <T> safeDatabaseCall(
    databaseCall: suspend () -> T
): Resource<T> {
    return try {
        Resource.Success(databaseCall())
    } catch (e: Exception) {
        Timber.e(e, "Database operation failed")
        Resource.Error("Database error: ${e.localizedMessage}")
    }
}

/**
 * Global exception handler for coroutines
 */
val coroutineExceptionHandler = CoroutineExceptionHandler { _, throwable ->
    Timber.e(throwable, "Caught exception in coroutine")
}

/**
 * Error message handler
 */
object ErrorHandler {
    fun getErrorMessage(error: Throwable): String {
        return when (error) {
            is java.net.UnknownHostException -> "No internet connection"
            is java.net.SocketTimeoutException -> "Connection timeout"
            is java.io.IOException -> "Network error occurred"
            is IllegalStateException -> "App is in an invalid state"
            is NullPointerException -> "Required data is missing"
            else -> error.localizedMessage ?: "An unexpected error occurred"
        }
    }
    
    fun handleError(context: Context, error: Throwable, showToast: Boolean = true) {
        val message = getErrorMessage(error)
        Timber.e(error, message)
        
        if (showToast) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }
}

/**
 * Retry mechanism for failed operations
 */
suspend fun <T> retryOperation(
    times: Int = 3,
    initialDelay: Long = 100,
    maxDelay: Long = 1000,
    factor: Double = 2.0,
    block: suspend () -> T
): T {
    var currentDelay = initialDelay
    repeat(times - 1) {
        try {
            return block()
        } catch (e: Exception) {
            Timber.w(e, "Retry attempt ${it + 1} failed")
        }
        kotlinx.coroutines.delay(currentDelay)
        currentDelay = (currentDelay * factor).toLong().coerceAtMost(maxDelay)
    }
    return block() // Last attempt
}

/**
 * Extension to show error Toast
 */
fun Context.showError(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

fun Context.showError(error: AuxError) {
    Toast.makeText(this, error.message, Toast.LENGTH_SHORT).show()
}

/**
 * Network availability checker
 */
fun Context.isNetworkAvailable(): Boolean {
    val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) 
        as android.net.ConnectivityManager
    val activeNetwork = connectivityManager.activeNetwork ?: return false
    val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
    return capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/**
 * Storage availability checker
 */
fun Context.hasEnoughStorage(requiredBytes: Long): Boolean {
    val stat = android.os.StatFs(filesDir.path)
    val availableBytes = stat.availableBlocksLong * stat.blockSizeLong
    return availableBytes > requiredBytes
}
