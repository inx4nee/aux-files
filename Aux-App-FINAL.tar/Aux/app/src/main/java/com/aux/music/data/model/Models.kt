package com.aux.music.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Main Song data model
 * Supports both YouTube and SoundCloud sources
 */
@Entity(tableName = "songs")
data class Song(
    @PrimaryKey
    val id: String,
    val title: String,
    val artist: String,
    val duration: Long, // in milliseconds
    val thumbnailUrl: String,
    val streamUrl: String? = null,
    val youtubeId: String = "",
    val soundCloudId: String? = null,
    val uploadDate: String? = null,
    val viewCount: Long? = null,
    val isDownloaded: Boolean = false,
    val localPath: String? = null,
    val addedTimestamp: Long = System.currentTimeMillis(),
    val source: String = "YOUTUBE" // "YOUTUBE" or "SOUNDCLOUD"
)

/**
 * Playlist model
 */
@Entity(tableName = "playlists")
data class Playlist(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val description: String? = null,
    val thumbnailUrl: String? = null,
    val createdTimestamp: Long = System.currentTimeMillis(),
    val songCount: Int = 0
)

/**
 * Many-to-many relationship between Playlist and Song
 */
@Entity(
    tableName = "playlist_song_cross_ref",
    primaryKeys = ["playlistId", "songId"]
)
data class PlaylistSongCrossRef(
    val playlistId: Long,
    val songId: String,
    val position: Int = 0
)

/**
 * User data model
 */
data class User(
    val uid: String,
    val email: String?,
    val displayName: String?,
    val photoUrl: String?
)

/**
 * Download status for songs
 */
enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    COMPLETED,
    FAILED,
    CANCELLED
}

/**
 * Download info model
 */
@Entity(tableName = "downloads")
data class Download(
    @PrimaryKey
    val songId: String,
    val status: DownloadStatus,
    val progress: Float = 0f,
    val localPath: String? = null,
    val errorMessage: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Search result model
 */
data class SearchResult(
    val songs: List<Song> = emptyList(),
    val nextPageToken: String? = null
)

/**
 * Player state
 */
data class PlayerState(
    val currentSong: Song? = null,
    val isPlaying: Boolean = false,
    val currentPosition: Long = 0L,
    val duration: Long = 0L,
    val queue: List<Song> = emptyList(),
    val currentIndex: Int = -1,
    val shuffleEnabled: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF
)

/**
 * Repeat modes
 */
enum class RepeatMode {
    OFF,
    ONE,
    ALL
}
