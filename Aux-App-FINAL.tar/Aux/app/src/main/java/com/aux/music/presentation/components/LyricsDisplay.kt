package com.aux.music.presentation.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aux.music.data.repository.LyricLine
import com.aux.music.data.repository.LyricsRepository
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * Lyrics display component with automatic fetching
 * Works with free APIs - no key needed!
 */
@Composable
fun LyricsDisplay(
    artist: String,
    title: String,
    currentPosition: Long,
    lyricsRepository: LyricsRepository,
    modifier: Modifier = Modifier
) {
    var lyrics by remember { mutableStateOf<List<LyricLine>>(emptyList()) }
    var plainLyrics by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showLyrics by remember { mutableStateOf(false) }
    var isSynced by remember { mutableStateOf(false) }
    
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    // Auto-scroll for synced lyrics
    LaunchedEffect(currentPosition, lyrics) {
        if (isSynced && lyrics.isNotEmpty()) {
            val currentLineIndex = lyrics.indexOfLast { it.timestamp <= currentPosition }
            if (currentLineIndex >= 0) {
                listState.animateScrollToItem(currentLineIndex)
            }
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        // Toggle button
        OutlinedButton(
            onClick = {
                if (!showLyrics && lyrics.isEmpty() && plainLyrics.isEmpty()) {
                    // Fetch lyrics first time
                    isLoading = true
                    error = null
                    
                    scope.launch {
                        // Try synced lyrics first
                        lyricsRepository.getSyncedLyrics(artist, title)
                            .onSuccess { syncedLines ->
                                lyrics = syncedLines
                                isSynced = true
                                isLoading = false
                                showLyrics = true
                                Timber.d("Loaded synced lyrics")
                            }
                            .onFailure {
                                // Fallback to plain lyrics
                                lyricsRepository.getLyrics(artist, title)
                                    .onSuccess { plainText ->
                                        plainLyrics = plainText
                                        isSynced = false
                                        isLoading = false
                                        showLyrics = true
                                        Timber.d("Loaded plain lyrics")
                                    }
                                    .onFailure { e ->
                                        error = "Lyrics not found"
                                        isLoading = false
                                        Timber.w(e, "Failed to load lyrics")
                                    }
                            }
                    }
                } else {
                    showLyrics = !showLyrics
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = when {
                    isLoading -> "Loading lyrics..."
                    showLyrics -> "Hide Lyrics"
                    else -> "Show Lyrics"
                }
            )
        }

        // Error message
        error?.let { errorMsg ->
            Text(
                text = errorMsg,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(8.dp)
            )
        }

        // Lyrics display
        AnimatedVisibility(visible = showLyrics && !isLoading) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .padding(top = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                if (isSynced && lyrics.isNotEmpty()) {
                    // Synced lyrics with auto-scroll
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        itemsIndexed(lyrics) { index, line ->
                            val currentLineIndex = lyrics.indexOfLast { 
                                it.timestamp <= currentPosition 
                            }
                            val isActive = index == currentLineIndex

                            Text(
                                text = line.text,
                                style = if (isActive) {
                                    MaterialTheme.typography.titleMedium
                                } else {
                                    MaterialTheme.typography.bodyLarge
                                },
                                color = if (isActive) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                                    .clickable {
                                        // Seek to this line when clicked
                                        // playerViewModel.seekTo(line.timestamp)
                                    },
                                textAlign = TextAlign.Center,
                                lineHeight = 24.sp
                            )
                        }
                    }
                } else if (plainLyrics.isNotEmpty()) {
                    // Plain lyrics (scrollable)
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        item {
                            Text(
                                text = plainLyrics,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 24.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    // No lyrics available
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "No lyrics available",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Loading indicator
        AnimatedVisibility(visible = isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        }
    }
}

/**
 * Simple lyrics display for manual lyrics
 */
@Composable
fun ManualLyricsInput(
    lyrics: String,
    onLyricsChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showInput by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { showInput = !showInput },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(if (showInput) "Hide Lyrics" else "Add/View Lyrics")
        }

        AnimatedVisibility(visible = showInput) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                OutlinedTextField(
                    value = lyrics,
                    onValueChange = onLyricsChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .padding(8.dp),
                    placeholder = { 
                        Text("Paste lyrics here or they'll be fetched automatically...") 
                    },
                    textStyle = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
