package com.aux.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.aux.music.presentation.components.BuyMeACoffeeDialog
import com.aux.music.presentation.components.SupportDeveloperDialog
import com.aux.music.presentation.components.SupportDialogManager
import com.aux.music.presentation.navigation.Navigation
import com.aux.music.presentation.theme.AuxTheme
import com.aux.music.util.Constants
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber

/**
 * Main Activity - Entry point of the app
 * Includes support dialog integration
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    
    private lateinit var supportManager: SupportDialogManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize Timber for logging
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        
        // Initialize support manager
        supportManager = SupportDialogManager(this)
        supportManager.incrementAppOpens()
        
        setContent {
            AuxTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AuxApp(supportManager = supportManager)
                }
            }
        }
    }
}

@Composable
fun AuxApp(supportManager: SupportDialogManager) {
    var showSupportDialog by remember { 
        mutableStateOf(supportManager.shouldShowSupportDialog()) 
    }
    var showCoffeeDialog by remember { mutableStateOf(false) }
    
    // Check if this is the 2nd time showing (show "Don't show again" option)
    val timesShown = supportManager.getTimesShown()
    val showDontShowAgainOption = timesShown >= 1 // Show on 2nd popup (index 1)
    
    // Main app navigation
    Navigation()
    
    // Support Dialog (after 100 app opens)
    if (showSupportDialog) {
        SupportDeveloperDialog(
            onDismiss = { 
                showSupportDialog = false
                // User closed dialog without action - still count as shown
                supportManager.markDialogShown()
            },
            onSupportClick = {
                showSupportDialog = false
                showCoffeeDialog = true
                supportManager.markDialogShown()
            },
            onNotNowClick = {
                showSupportDialog = false
                supportManager.markDialogShown()
            },
            onDontShowAgain = if (showDontShowAgainOption) {
                {
                    showSupportDialog = false
                    supportManager.dontShowAgain()
                    Timber.d("User selected 'Don't show again'")
                }
            } else null,
            showDontShowAgainOption = showDontShowAgainOption
        )
    }
    
    // Buy Me a Coffee Dialog
    if (showCoffeeDialog) {
        BuyMeACoffeeDialog(
            onDismiss = { showCoffeeDialog = false },
            buyMeACoffeeUrl = Constants.BUY_ME_A_COFFEE_URL
        )
    }
}
