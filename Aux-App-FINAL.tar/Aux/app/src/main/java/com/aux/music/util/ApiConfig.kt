package com.aux.music.util

/**
 * API Configuration
 * 
 * ADD YOUR GENIUS API KEY HERE!
 * 
 * How to get a Genius API key:
 * 1. Go to https://genius.com/api-clients
 * 2. Sign up or log in
 * 3. Create a new API client
 * 4. Copy your "Client Access Token"
 * 5. Paste it below
 */

object ApiConfig {
    
    /**
     * 🔑 PASTE YOUR GENIUS API KEY HERE
     * 
     * Example: "your_genius_api_key_here"
     */
    const val GENIUS_API_KEY = "YOUR_API_KEY_HERE"
    
    /**
     * Check if API key is configured
     */
    fun isGeniusApiConfigured(): Boolean {
        return GENIUS_API_KEY != "YOUR_API_KEY_HERE" && GENIUS_API_KEY.isNotBlank()
    }
}
