# 🎵 Aux Music Player

A modern, feature-rich Android music streaming app with YouTube and SoundCloud integration.

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Platform](https://img.shields.io/badge/platform-Android-green)
![Kotlin](https://img.shields.io/badge/kotlin-1.9.20-purple)
![MinSDK](https://img.shields.io/badge/minSDK-26-orange)

---

## ✨ Features

### **Music Streaming**
- 🎵 YouTube streaming via NewPipe
- ☁️ SoundCloud streaming support
- 🔄 Switch between sources seamlessly
- 🔍 Advanced search with filters
- 📜 Search history

### **Playback Features**
- ⚡ Speed control (0.5x - 2.0x)
- 🎚️ Pitch adjustment
- 🔊 Audio effects (Bass Boost, 3D Surround, Reverb)
- ⏱️ Advanced sleep timer with fade out
- 🔖 Bookmarks for long tracks
- 📋 Queue management

### **Library & Organization**
- 📚 Personal library
- 🎼 Custom playlists
- 📊 Music statistics & listening history
- 🤖 Smart auto-generated playlists
- 💡 Recommendations

### **Customization**
- 🎨 8 theme presets + custom colors
- 🌈 Material You dynamic colors
- 🌙 OLED black mode
- 📱 Lock screen controls
- 👆 Custom gestures (swipe to skip)

### **Advanced**
- 📝 Lyrics display (auto-fetch)
- 💾 Downloads & offline mode
- 🔄 Backup & restore
- 📤 Share songs & playlists
- 🎯 Quality selector
- 💾 Storage management

---

## 🚀 Quick Start

### **Prerequisites**
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17 or newer
- Android SDK 34
- Minimum Android 8.0 (API 26)

### **Build Steps**

1. **Open in Android Studio**
   - File → Open
   - Select this folder
   - Wait for Gradle sync (5-10 minutes first time)

2. **Add App Icon (Optional)**
   - Right-click `res` → New → Image Asset
   - Select your icon image
   - Click Finish

3. **Build & Run**
   - Connect device or start emulator
   - Click Run button (▶️)
   - App installs and launches!

---

## 🏗️ Architecture

**Tech Stack:** Kotlin, Jetpack Compose, Material Design 3, MVVM, Hilt, Room, Media3, NewPipe

**Project Structure:**
```
app/src/main/java/com/aux/music/
├── data/              # Repositories, Database, API
├── presentation/      # Screens, ViewModels, Components
├── service/           # Media player service
├── util/              # Constants, Utilities
└── di/                # Dependency injection
```

---

## 🎨 Customization

Edit `util/Constants.kt` to customize:
```kotlin
const val DEVELOPER_NAME = "Kamui Hub"
const val GITHUB_URL = "https://github.com/inx4nee"
const val BUY_ME_A_COFFEE_URL = "https://buymeacoffee.com/Sainnee"
```

---

## 📚 Documentation

See `/Aux-Documentation/` folder for detailed guides on features, setup, and customization.

---

## 👨‍💻 Developer

**Kamui Hub**
- GitHub: [@inx4nee](https://github.com/inx4nee)
- Support: [Buy Me a Coffee](https://buymeacoffee.com/Sainnee)

---

## 📄 License

Educational purposes only. Uses open source libraries (NewPipe, Jetpack, etc.)

Not affiliated with YouTube or SoundCloud.

---

**Built with ❤️ using Kotlin & Jetpack Compose**

© 2025 Kamui Hub. All rights reserved.
