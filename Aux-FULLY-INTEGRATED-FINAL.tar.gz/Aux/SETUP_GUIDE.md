# Aux Setup Guide - Super Simple (No Firebase!)

This guide will walk you through setting up and running Aux on Android Studio.

## Prerequisites Checklist

Before you begin, make sure you have:

- [ ] A computer (Windows, Mac, or Linux)
- [ ] At least 8GB RAM (16GB recommended)
- [ ] At least 10GB free disk space
- [ ] Stable internet connection (for downloading dependencies)

## Step 1: Install Android Studio

### Download
1. Visit https://developer.android.com/studio
2. Download Android Studio for your operating system
3. Run the installer

### Installation
1. Follow the setup wizard
2. Choose "Standard" installation type
3. Accept all component licenses
4. Wait for installation (15-30 minutes)

### First Launch
1. Open Android Studio
2. Complete the first-run wizard
3. Download any additional SDK components if prompted

## Step 2: Open the Project

### Import Project
1. Open Android Studio
2. Click "Open" on the welcome screen
3. Navigate to the Aux folder (extract it first if it's compressed)
4. Click "OK"

### Sync Gradle
1. Android Studio will automatically detect the project
2. Click "Sync Now" when prompted at the top
3. Wait for Gradle sync (first time may take 5-10 minutes)
4. All dependencies download automatically

### Resolve Any Errors
If you see errors:
- Try: File > Invalidate Caches > Invalidate and Restart
- Ensure you have internet connection
- Check that JDK 17 is installed

## Step 3: Build the App

### Build Project
1. In Android Studio, select "Build" > "Make Project"
2. Wait for build to complete
3. Check Build Output at bottom
4. Look for "BUILD SUCCESSFUL"

### Common Build Issues

**"SDK location not found"**
- Fix: File > Project Structure > SDK Location
- Set Android SDK location (usually auto-detected)

**"Gradle sync failed"**
- Fix: Tools > SDK Manager
- Install missing SDK components
- Click "Sync Now" again

**"Cannot resolve symbol"**
- Fix: Build > Clean Project
- Then Build > Rebuild Project

## Step 4: Run the App

### Option A: Physical Device

**Enable Developer Mode:**
1. On your Android phone: Settings > About phone
2. Tap "Build number" 7 times
3. Go back to Settings > Developer options
4. Enable "USB debugging"

**Run:**
1. Connect device via USB
2. Allow USB debugging on phone
3. In Android Studio, select your device from dropdown
4. Click green "Run" button (▶️)
5. Wait for install and launch

### Option B: Emulator

**Create Virtual Device:**
1. Click "Device Manager" on right sidebar
2. Click "Create Device"
3. Select device (e.g., "Pixel 6")
4. Click "Next"
5. Select system image (e.g., "S" for Android 12)
   - Click "Download" if needed
6. Click "Next" then "Finish"

**Run:**
1. Start your emulator
2. Wait for it to boot (2-3 minutes first time)
3. Click green "Run" button in Android Studio
4. Select your emulator
5. Wait for install and launch

## Step 5: Test the App

### First Launch
1. Grant permissions when requested
2. You'll see the Home screen
3. Tap "Search" tab
4. Search for a song
5. Tap to play
6. Song appears in Library

### Test Features
- ✅ Search for songs
- ✅ Play music
- ✅ Check Library
- ✅ Create playlist
- ✅ Background playback

## Common Issues

### App Crashes on Launch
- Check Logcat tab for errors
- Clean and rebuild project
- Try different device/emulator

### No Search Results
- Check internet connection
- Try popular song names
- NewPipe may need updating

### No Audio
- Check volume
- Check permissions granted
- Restart app

## That's It!

**You now have a working music streaming app!**

No Firebase setup needed!
No Google Services configuration!
No cloud accounts!

Just pure Android development! 🎉

## Next Steps

- Explore the code
- Customize the UI
- Add new features
- Learn from the architecture

## Quick Reference

### Keyboard Shortcuts
- **Build**: `Ctrl/Cmd + F9`
- **Run**: `Shift + F10`
- **Debug**: `Shift + F9`

### Important Files
- `MainActivity.kt` - App entry point
- `HomeScreen.kt` - Home UI
- `SearchScreen.kt` - Search UI
- `LibraryScreen.kt` - Library UI

### Useful Tools
- **Logcat** - View logs and errors
- **Device Manager** - Manage emulators
- **Build Output** - See build progress

## Getting Help

- Check Logcat for errors
- Search Stack Overflow
- Read Android docs: developer.android.com
- Check NewPipe GitHub for YouTube issues

---

**Happy coding! 🚀**

The setup is literally:
1. Open project
2. Sync Gradle
3. Run

That's it! No complicated cloud setup!
