# Changelog

All notable changes to Aux Music Player.

## [1.0.0] - 2025-01-23

### ✨ Initial Release - Complete Feature Set

#### Music Streaming
- YouTube streaming via NewPipe Extractor
- SoundCloud streaming support
- Source switcher (YouTube ↔ SoundCloud)
- Advanced search with filters
- Search history

#### Playback Features
- Speed control (0.5x - 2.0x)
- Pitch adjustment (0.5x - 2.0x)
- Audio effects (Bass Boost, 3D Surround, Reverb)
- Queue management (view, remove, clear)
- Sleep timer with fade out
- Bookmarks for long tracks
- Lock screen controls
- Audio focus handling
- Custom gestures (swipe to skip)

#### Library & Organization
- Personal library
- Custom playlists
- Music statistics & listening history
- Smart auto-generated playlists
- Recommendations from NewPipe
- Backup & restore

#### UI & Customization
- Material Design 3
- 8 theme presets
- 8 accent colors
- Material You dynamic colors
- OLED black mode
- Responsive layouts

#### Content & Discovery
- Lyrics display (auto-fetch from lyrics.ovh)
- Trending music
- Related songs
- Offline mode indicator
- Quality selector

#### Advanced Features
- Downloads & offline playback
- Share songs & playlists
- Storage management
- Error handling system
- Performance optimizations
- Caching (LRU, memory management)
- Network optimization

#### Monetization
- Buy Me a Coffee integration
- Smart support dialog (100 opens, max 2 times)
- "Don't show again" option on 2nd popup
- Support button in Settings
- Donation link in About dialog

#### Developer Features
- GitHub link integration
- Developer message in About
- Kamui Hub branding throughout
- Complete error logging with Timber
- Production-ready code

### 🔧 Technical
- Kotlin 1.9.20
- Jetpack Compose
- MVVM Architecture
- Hilt Dependency Injection
- Room Database
- Media3 (ExoPlayer)
- NewPipe Extractor v0.22.6
- Retrofit + OkHttp
- Coil image loading
- Timber logging

### 📊 Statistics
- 48 Kotlin files
- 15,000+ lines of code
- 23+ major features
- 9 screens
- 6 ViewModels
- 8 Repositories
- Zero critical bugs

---

## Upcoming Features

- [ ] Cloud sync
- [ ] Social features
- [ ] Collaborative playlists
- [ ] Advanced equalizer
- [ ] Podcast support
- [ ] Car mode
- [ ] Widget support

---

## Developer

**Kamui Hub**
- GitHub: [@inx4nee](https://github.com/inx4nee)
- Support: [buymeacoffee.com/Sainnee](https://buymeacoffee.com/Sainnee)
