package com.aux.music.data.api

import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * InnerTube API Client
 * Direct access to YouTube Music's internal API for better recommendations
 * and next song suggestions
 */
@Singleton
class InnerTubeApi @Inject constructor() {

    companion object {
        private const val BASE_URL = "https://music.youtube.com/youtubei/v1"
        private const val API_KEY = "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30"
        
        // InnerTube client configuration
        private const val CLIENT_NAME = "WEB_REMIX"
        private const val CLIENT_VERSION = "1.20231211.01.00"
        
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    /**
     * Get next/recommended songs based on current video
     */
    suspend fun getNext(videoId: String): Result<NextResponse> = withContext(Dispatchers.IO) {
        try {
            val requestBody = createNextRequestBody(videoId)
            val request = Request.Builder()
                .url("$BASE_URL/next?key=$API_KEY")
                .post(requestBody.toRequestBody(JSON_MEDIA_TYPE))
                .addHeader("Content-Type", "application/json")
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .addHeader("X-YouTube-Client-Name", "67")
                .addHeader("X-YouTube-Client-Version", CLIENT_VERSION)
                .build()

            val response = client.newCall(request).execute()
            
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Request failed: ${response.code}"))
            }

            val body = response.body?.string()
                ?: return@withContext Result.failure(Exception("Empty response"))

            val nextResponse = parseNextResponse(body)
            Result.success(nextResponse)
            
        } catch (e: Exception) {
            Timber.e(e, "Failed to get next songs")
            Result.failure(e)
        }
    }

    /**
     * Get mix/radio based on a song
     */
    suspend fun getRadio(videoId: String, playlistId: String? = null): Result<RadioResponse> = 
        withContext(Dispatchers.IO) {
        try {
            val requestBody = createRadioRequestBody(videoId, playlistId)
            val request = Request.Builder()
                .url("$BASE_URL/next?key=$API_KEY")
                .post(requestBody.toRequestBody(JSON_MEDIA_TYPE))
                .addHeader("Content-Type", "application/json")
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()

            val response = client.newCall(request).execute()
            
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Request failed: ${response.code}"))
            }

            val body = response.body?.string()
                ?: return@withContext Result.failure(Exception("Empty response"))

            val radioResponse = parseRadioResponse(body)
            Result.success(radioResponse)
            
        } catch (e: Exception) {
            Timber.e(e, "Failed to get radio")
            Result.failure(e)
        }
    }

    /**
     * Get personalized recommendations based on listening history
     */
    suspend fun getRecommendations(browseId: String = "FEmusic_home"): Result<RecommendationsResponse> = 
        withContext(Dispatchers.IO) {
        try {
            val requestBody = createBrowseRequestBody(browseId)
            val request = Request.Builder()
                .url("$BASE_URL/browse?key=$API_KEY")
                .post(requestBody.toRequestBody(JSON_MEDIA_TYPE))
                .addHeader("Content-Type", "application/json")
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()

            val response = client.newCall(request).execute()
            
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Request failed: ${response.code}"))
            }

            val body = response.body?.string()
                ?: return@withContext Result.failure(Exception("Empty response"))

            val recommendations = parseRecommendationsResponse(body)
            Result.success(recommendations)
            
        } catch (e: Exception) {
            Timber.e(e, "Failed to get recommendations")
            Result.failure(e)
        }
    }

    private fun createNextRequestBody(videoId: String): String {
        val context = mapOf(
            "client" to mapOf(
                "clientName" to CLIENT_NAME,
                "clientVersion" to CLIENT_VERSION,
                "hl" to "en",
                "gl" to "US"
            )
        )

        val body = mapOf(
            "context" to context,
            "videoId" to videoId,
            "enablePersistentPlaylistPanel" to true,
            "isAudioOnly" to true,
            "tunerSettingValue" to "AUTOMIX_SETTING_NORMAL"
        )

        return gson.toJson(body)
    }

    private fun createRadioRequestBody(videoId: String, playlistId: String?): String {
        val context = mapOf(
            "client" to mapOf(
                "clientName" to CLIENT_NAME,
                "clientVersion" to CLIENT_VERSION,
                "hl" to "en",
                "gl" to "US"
            )
        )

        val body = mutableMapOf(
            "context" to context,
            "videoId" to videoId,
            "playlistId" to (playlistId ?: "RDAMVM$videoId")
        )

        return gson.toJson(body)
    }

    private fun createBrowseRequestBody(browseId: String): String {
        val context = mapOf(
            "client" to mapOf(
                "clientName" to CLIENT_NAME,
                "clientVersion" to CLIENT_VERSION,
                "hl" to "en",
                "gl" to "US"
            )
        )

        val body = mapOf(
            "context" to context,
            "browseId" to browseId
        )

        return gson.toJson(body)
    }

    private fun parseNextResponse(json: String): NextResponse {
        val jsonObject = gson.fromJson(json, JsonObject::class.java)
        val songs = mutableListOf<InnerTubeSong>()

        try {
            val contents = jsonObject
                .getAsJsonObject("contents")
                ?.getAsJsonObject("singleColumnMusicWatchNextResultsRenderer")
                ?.getAsJsonObject("tabbedRenderer")
                ?.getAsJsonObject("watchNextTabbedResultsRenderer")
                ?.getAsJsonArray("tabs")
                ?.get(0)?.asJsonObject
                ?.getAsJsonObject("tabRenderer")
                ?.getAsJsonObject("content")
                ?.getAsJsonObject("musicQueueRenderer")
                ?.getAsJsonObject("content")
                ?.getAsJsonObject("playlistPanelRenderer")
                ?.getAsJsonArray("contents")

            contents?.forEach { item ->
                try {
                    val playlistItem = item.asJsonObject
                        .getAsJsonObject("playlistPanelVideoRenderer")

                    if (playlistItem != null) {
                        val song = parsePlaylistItem(playlistItem)
                        songs.add(song)
                    }
                } catch (e: Exception) {
                    Timber.w(e, "Failed to parse playlist item")
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to parse next response")
        }

        return NextResponse(songs = songs)
    }

    private fun parseRadioResponse(json: String): RadioResponse {
        val nextResponse = parseNextResponse(json)
        return RadioResponse(
            songs = nextResponse.songs,
            playlistId = extractPlaylistId(json)
        )
    }

    private fun parseRecommendationsResponse(json: String): RecommendationsResponse {
        val jsonObject = gson.fromJson(json, JsonObject::class.java)
        val sections = mutableListOf<RecommendationSection>()

        try {
            val shelves = jsonObject
                .getAsJsonObject("contents")
                ?.getAsJsonObject("singleColumnBrowseResultsRenderer")
                ?.getAsJsonArray("tabs")
                ?.get(0)?.asJsonObject
                ?.getAsJsonObject("tabRenderer")
                ?.getAsJsonObject("content")
                ?.getAsJsonObject("sectionListRenderer")
                ?.getAsJsonArray("contents")

            shelves?.forEach { shelf ->
                try {
                    val section = parseRecommendationSection(shelf.asJsonObject)
                    if (section != null) {
                        sections.add(section)
                    }
                } catch (e: Exception) {
                    Timber.w(e, "Failed to parse recommendation section")
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to parse recommendations response")
        }

        return RecommendationsResponse(sections = sections)
    }

    private fun parsePlaylistItem(item: JsonObject): InnerTubeSong {
        val videoId = item.get("videoId")?.asString ?: ""
        
        val title = item.getAsJsonArray("title")?.get(0)?.asJsonObject
            ?.get("text")?.asString ?: ""

        val artist = item.getAsJsonArray("longBylineText")?.get(0)?.asJsonObject
            ?.getAsJsonArray("runs")?.get(0)?.asJsonObject
            ?.get("text")?.asString ?: ""

        val thumbnail = item.getAsJsonObject("thumbnail")
            ?.getAsJsonArray("thumbnails")?.get(0)?.asJsonObject
            ?.get("url")?.asString ?: ""

        val durationText = item.get("lengthText")?.asJsonObject
            ?.get("simpleText")?.asString ?: "0:00"

        return InnerTubeSong(
            videoId = videoId,
            title = title,
            artist = artist,
            thumbnailUrl = thumbnail,
            duration = parseDuration(durationText)
        )
    }

    private fun parseRecommendationSection(shelf: JsonObject): RecommendationSection? {
        val musicShelf = shelf.getAsJsonObject("musicCarouselShelfRenderer")
            ?: shelf.getAsJsonObject("musicShelfRenderer")
            ?: return null

        val title = musicShelf.getAsJsonObject("header")
            ?.getAsJsonObject("musicCarouselShelfBasicHeaderRenderer")
            ?.getAsJsonObject("title")
            ?.getAsJsonArray("runs")?.get(0)?.asJsonObject
            ?.get("text")?.asString ?: "Recommended"

        val songs = mutableListOf<InnerTubeSong>()
        val contents = musicShelf.getAsJsonArray("contents")

        contents?.forEach { item ->
            try {
                val renderer = item.asJsonObject
                    .getAsJsonObject("musicResponsiveListItemRenderer")
                    ?: item.asJsonObject.getAsJsonObject("musicTwoRowItemRenderer")

                if (renderer != null) {
                    val song = parseResponsiveItem(renderer)
                    songs.add(song)
                }
            } catch (e: Exception) {
                Timber.w(e, "Failed to parse recommendation item")
            }
        }

        return RecommendationSection(
            title = title,
            songs = songs
        )
    }

    private fun parseResponsiveItem(item: JsonObject): InnerTubeSong {
        val videoId = item.getAsJsonObject("playlistItemData")
            ?.get("videoId")?.asString ?: ""

        val flexColumns = item.getAsJsonArray("flexColumns")

        val title = flexColumns?.get(0)?.asJsonObject
            ?.getAsJsonObject("musicResponsiveListItemFlexColumnRenderer")
            ?.getAsJsonObject("text")
            ?.getAsJsonArray("runs")?.get(0)?.asJsonObject
            ?.get("text")?.asString ?: ""

        val artist = flexColumns?.get(1)?.asJsonObject
            ?.getAsJsonObject("musicResponsiveListItemFlexColumnRenderer")
            ?.getAsJsonObject("text")
            ?.getAsJsonArray("runs")?.get(0)?.asJsonObject
            ?.get("text")?.asString ?: ""

        val thumbnail = item.getAsJsonObject("thumbnail")
            ?.getAsJsonObject("musicThumbnailRenderer")
            ?.getAsJsonObject("thumbnail")
            ?.getAsJsonArray("thumbnails")?.get(0)?.asJsonObject
            ?.get("url")?.asString ?: ""

        return InnerTubeSong(
            videoId = videoId,
            title = title,
            artist = artist,
            thumbnailUrl = thumbnail,
            duration = 0L
        )
    }

    private fun extractPlaylistId(json: String): String? {
        return try {
            val jsonObject = gson.fromJson(json, JsonObject::class.java)
            jsonObject.getAsJsonObject("contents")
                ?.getAsJsonObject("singleColumnMusicWatchNextResultsRenderer")
                ?.getAsJsonObject("tabbedRenderer")
                ?.getAsJsonObject("watchNextTabbedResultsRenderer")
                ?.getAsJsonObject("playlist")
                ?.get("playlistId")?.asString
        } catch (e: Exception) {
            null
        }
    }

    private fun parseDuration(duration: String): Long {
        return try {
            val parts = duration.split(":")
            when (parts.size) {
                2 -> (parts[0].toLong() * 60 + parts[1].toLong()) * 1000
                3 -> (parts[0].toLong() * 3600 + parts[1].toLong() * 60 + parts[2].toLong()) * 1000
                else -> 0L
            }
        } catch (e: Exception) {
            0L
        }
    }
}

/**
 * Data classes for InnerTube responses
 */
data class InnerTubeSong(
    val videoId: String,
    val title: String,
    val artist: String,
    val thumbnailUrl: String,
    val duration: Long
)

data class NextResponse(
    val songs: List<InnerTubeSong>
)

data class RadioResponse(
    val songs: List<InnerTubeSong>,
    val playlistId: String?
)

data class RecommendationSection(
    val title: String,
    val songs: List<InnerTubeSong>
)

data class RecommendationsResponse(
    val sections: List<RecommendationSection>
)
