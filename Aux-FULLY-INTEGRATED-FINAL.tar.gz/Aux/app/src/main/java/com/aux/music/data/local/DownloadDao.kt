package com.aux.music.data.local

import androidx.room.*
import com.aux.music.data.model.Download
import com.aux.music.data.model.DownloadStatus
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for Download operations
 */
@Dao
interface DownloadDao {
    
    @Query("SELECT * FROM downloads ORDER BY timestamp DESC")
    fun getAllDownloads(): Flow<List<Download>>
    
    @Query("SELECT * FROM downloads WHERE songId = :songId")
    suspend fun getDownloadById(songId: String): Download?
    
    @Query("SELECT * FROM downloads WHERE status = :status")
    fun getDownloadsByStatus(status: DownloadStatus): Flow<List<Download>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: Download)
    
    @Update
    suspend fun updateDownload(download: Download)
    
    @Delete
    suspend fun deleteDownload(download: Download)
    
    @Query("DELETE FROM downloads WHERE songId = :songId")
    suspend fun deleteDownloadById(songId: String)
    
    @Query("UPDATE downloads SET progress = :progress WHERE songId = :songId")
    suspend fun updateProgress(songId: String, progress: Float)
    
    @Query("UPDATE downloads SET status = :status WHERE songId = :songId")
    suspend fun updateStatus(songId: String, status: DownloadStatus)
}
