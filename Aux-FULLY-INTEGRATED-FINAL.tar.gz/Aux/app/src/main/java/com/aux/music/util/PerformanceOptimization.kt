package com.aux.music.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.security.MessageDigest

/**
 * Performance optimization utilities
 */

/**
 * Memory cache for images with LRU eviction
 */
class MemoryCache<K, V>(private val maxSize: Int) {
    private val cache = object : LinkedHashMap<K, V>(maxSize, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, V>?): Boolean {
            return size > maxSize
        }
    }

    @Synchronized
    fun get(key: K): V? = cache[key]

    @Synchronized
    fun put(key: K, value: V) {
        cache[key] = value
    }

    @Synchronized
    fun remove(key: K): V? = cache.remove(key)

    @Synchronized
    fun clear() = cache.clear()

    @Synchronized
    fun size() = cache.size
}

/**
 * Image optimization utilities
 */
object ImageOptimizer {
    /**
     * Decode bitmap with proper sampling to save memory
     */
    fun decodeSampledBitmap(
        inputStream: InputStream,
        reqWidth: Int,
        reqHeight: Int
    ): Bitmap? {
        return try {
            // First decode with inJustDecodeBounds=true to check dimensions
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeStream(inputStream, null, options)

            // Calculate inSampleSize
            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)

            // Decode bitmap with inSampleSize set
            options.inJustDecodeBounds = false
            options.inPreferredConfig = Bitmap.Config.RGB_565 // Use less memory
            
            inputStream.reset()
            BitmapFactory.decodeStream(inputStream, null, options)
        } catch (e: Exception) {
            Timber.e(e, "Failed to decode bitmap")
            null
        }
    }

    private fun calculateInSampleSize(
        options: BitmapFactory.Options,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        val (height: Int, width: Int) = options.run { outHeight to outWidth }
        var inSampleSize = 1

        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2

            while (halfHeight / inSampleSize >= reqHeight &&
                halfWidth / inSampleSize >= reqWidth
            ) {
                inSampleSize *= 2
            }
        }

        return inSampleSize
    }

    /**
     * Compress bitmap to reduce size
     */
    fun compressBitmap(bitmap: Bitmap, quality: Int = 85): ByteArray {
        val outputStream = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        return outputStream.toByteArray()
    }
}

/**
 * Debounce function for search queries
 */
class Debouncer(private val delayMillis: Long = 300L) {
    private var job: kotlinx.coroutines.Job? = null

    fun debounce(
        scope: kotlinx.coroutines.CoroutineScope,
        action: suspend () -> Unit
    ) {
        job?.cancel()
        job = scope.launch {
            kotlinx.coroutines.delay(delayMillis)
            action()
        }
    }

    fun cancel() {
        job?.cancel()
    }
}

/**
 * Lazy pagination helper
 */
class PaginationHelper<T>(
    private val pageSize: Int = 20,
    private val loadMore: suspend (page: Int) -> List<T>
) {
    private var currentPage = 0
    private var isLoading = false
    private var hasMore = true

    suspend fun loadNextPage(): List<T>? {
        if (isLoading || !hasMore) return null

        isLoading = true
        return try {
            val items = loadMore(currentPage)
            if (items.size < pageSize) {
                hasMore = false
            }
            currentPage++
            items
        } catch (e: Exception) {
            Timber.e(e, "Failed to load page $currentPage")
            null
        } finally {
            isLoading = false
        }
    }

    fun reset() {
        currentPage = 0
        hasMore = true
        isLoading = false
    }
}

/**
 * Database batch operations for better performance
 */
suspend fun <T> batchInsert(
    items: List<T>,
    batchSize: Int = 100,
    insert: suspend (List<T>) -> Unit
) {
    withContext(Dispatchers.IO) {
        items.chunked(batchSize).forEach { batch ->
            insert(batch)
        }
    }
}

/**
 * Flow optimization extensions
 */
fun <T> Flow<T>.optimizeForUI(): Flow<T> {
    return this.flowOn(Dispatchers.IO)
}

/**
 * Collect flow safely in composable with lifecycle awareness
 */
@Composable
fun <T> Flow<T>.collectAsStateLifecycleAware(
    initial: T,
    lifecycle: Lifecycle = LocalLifecycleOwner.current.lifecycle,
    minActiveState: Lifecycle.State = Lifecycle.State.STARTED
): State<T> {
    val state = remember { mutableStateOf(initial) }
    
    LaunchedEffect(this, lifecycle, minActiveState) {
        lifecycle.repeatOnLifecycle(minActiveState) {
            this@collectAsStateLifecycleAware.collect {
                state.value = it
            }
        }
    }
    
    return state
}

/**
 * Cache manager for downloaded files
 */
class CacheManager(private val cacheDir: File) {
    private val maxCacheSize = 500 * 1024 * 1024L // 500 MB

    suspend fun getCachedFile(key: String): File? = withContext(Dispatchers.IO) {
        val file = File(cacheDir, key.hashFileName())
        if (file.exists()) file else null
    }

    suspend fun cacheFile(key: String, data: ByteArray): File = withContext(Dispatchers.IO) {
        ensureCacheSize()
        val file = File(cacheDir, key.hashFileName())
        file.writeBytes(data)
        file
    }

    private fun ensureCacheSize() {
        val files = cacheDir.listFiles() ?: return
        val totalSize = files.sumOf { it.length() }

        if (totalSize > maxCacheSize) {
            // Delete oldest files first
            files.sortedBy { it.lastModified() }
                .take((files.size * 0.3).toInt()) // Delete 30% of files
                .forEach { it.delete() }
        }
    }

    fun clearCache() {
        cacheDir.listFiles()?.forEach { it.delete() }
    }

    private fun String.hashFileName(): String {
        val bytes = MessageDigest.getInstance("MD5").digest(this.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}

/**
 * Prevent memory leaks in ViewModels
 */
abstract class DisposableViewModel : androidx.lifecycle.ViewModel() {
    protected val disposables = mutableListOf<kotlinx.coroutines.Job>()

    override fun onCleared() {
        super.onCleared()
        disposables.forEach { it.cancel() }
        disposables.clear()
    }

    protected fun kotlinx.coroutines.Job.addToDisposables() {
        disposables.add(this)
    }
}

/**
 * Lazy loading for lists
 */
@Composable
fun rememberLazyLoadingState(
    itemCount: Int,
    loadMoreThreshold: Int = 5,
    onLoadMore: () -> Unit
) {
    LaunchedEffect(itemCount) {
        snapshotFlow { itemCount }
            .collect { count ->
                if (count > 0 && count % loadMoreThreshold == 0) {
                    onLoadMore()
                }
            }
    }
}

/**
 * String pooling to reduce memory
 */
object StringPool {
    private val pool = mutableMapOf<String, String>()

    fun intern(string: String): String {
        return pool.getOrPut(string) { string }
    }

    fun clear() {
        pool.clear()
    }
}

/**
 * Optimize RecyclerView/LazyColumn performance
 */
data class ListUpdate<T>(
    val oldList: List<T>,
    val newList: List<T>
) {
    fun calculateDiff(
        areItemsTheSame: (T, T) -> Boolean,
        areContentsTheSame: (T, T) -> Boolean
    ): DiffResult {
        // Use DiffUtil for efficient list updates
        return DiffResult(
            insertions = newList.filterNot { newItem ->
                oldList.any { oldItem -> areItemsTheSame(oldItem, newItem) }
            },
            deletions = oldList.filterNot { oldItem ->
                newList.any { newItem -> areItemsTheSame(oldItem, newItem) }
            },
            modifications = newList.filter { newItem ->
                oldList.any { oldItem ->
                    areItemsTheSame(oldItem, newItem) && 
                    !areContentsTheSame(oldItem, newItem)
                }
            }
        )
    }
}

data class DiffResult<T>(
    val insertions: List<T>,
    val deletions: List<T>,
    val modifications: List<T>
)

/**
 * Background job scheduler for periodic tasks
 */
class BackgroundTaskScheduler(private val context: Context) {
    fun schedulePeriodicTask(
        taskId: String,
        intervalHours: Long,
        work: suspend () -> Unit
    ) {
        val workRequest = androidx.work.PeriodicWorkRequestBuilder<BackgroundWorker>(
            intervalHours,
            java.util.concurrent.TimeUnit.HOURS
        )
            .setConstraints(
                androidx.work.Constraints.Builder()
                    .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED)
                    .setRequiresBatteryNotLow(true)
                    .build()
            )
            .addTag(taskId)
            .build()

        androidx.work.WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(
                taskId,
                androidx.work.ExistingPeriodicWorkPolicy.KEEP,
                workRequest
            )
    }
}

class BackgroundWorker(
    context: Context,
    params: androidx.work.WorkerParameters
) : androidx.work.CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            // Perform background work
            Result.success()
        } catch (e: Exception) {
            Timber.e(e, "Background work failed")
            Result.retry()
        }
    }
}

/**
 * Bitmap pool for reusing bitmaps
 */
object BitmapPool {
    private val pool = mutableListOf<Bitmap>()
    private const val MAX_POOL_SIZE = 10

    fun obtain(width: Int, height: Int): Bitmap {
        synchronized(pool) {
            val bitmap = pool.find { 
                it.width >= width && it.height >= height && !it.isRecycled
            }
            
            return if (bitmap != null) {
                pool.remove(bitmap)
                bitmap
            } else {
                Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            }
        }
    }

    fun recycle(bitmap: Bitmap) {
        synchronized(pool) {
            if (pool.size < MAX_POOL_SIZE && !bitmap.isRecycled) {
                pool.add(bitmap)
            } else {
                bitmap.recycle()
            }
        }
    }

    fun clear() {
        synchronized(pool) {
            pool.forEach { it.recycle() }
            pool.clear()
        }
    }
}
