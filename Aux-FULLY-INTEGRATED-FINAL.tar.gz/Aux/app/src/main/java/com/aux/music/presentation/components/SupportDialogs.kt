package com.aux.music.presentation.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Support the Developer Dialog
 * Shows after user has used the app for a while
 */
@Composable
fun SupportDeveloperDialog(
    onDismiss: () -> Unit,
    onSupportClick: () -> Unit,
    onNotNowClick: () -> Unit,
    onDontShowAgain: (() -> Unit)? = null,
    showDontShowAgainOption: Boolean = false
) {
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = {
            Text(
                text = "Enjoying Aux?",
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "I'm so glad you're enjoying the app! 😊",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center
                )
                
                Text(
                    text = "Aux is completely free with no ads. If you'd like to support continued development and new features, consider buying me a coffee!",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalCafe,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Your support means the world! ☕",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }

                Text(
                    text = "No pressure though! Enjoy the app either way! 🎵",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                // Show "Don't show again" option after 2nd popup
                if (showDontShowAgainOption && onDontShowAgain != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(
                        onClick = onDontShowAgain,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Don't show this again",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        },
        confirmButton = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSupportClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Support Development")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onNotNowClick) {
                Text("Maybe Later")
            }
        }
    )
}

/**
 * Buy Me a Coffee Dialog
 * Direct donation dialog
 */
@Composable
fun BuyMeACoffeeDialog(
    onDismiss: () -> Unit,
    buyMeACoffeeUrl: String
) {
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.LocalCafe,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = {
            Text(
                text = "Buy Me a Coffee ☕",
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Thank you for considering supporting Aux!",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.primary
                )
                
                Divider()

                Text(
                    text = "Your donations help:",
                    style = MaterialTheme.typography.titleSmall
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SupportItem(
                        icon = Icons.Default.Code,
                        text = "Continue development"
                    )
                    SupportItem(
                        icon = Icons.Default.BugReport,
                        text = "Fix bugs faster"
                    )
                    SupportItem(
                        icon = Icons.Default.StarRate,
                        text = "Add new features"
                    )
                    SupportItem(
                        icon = Icons.Default.CloudQueue,
                        text = "Cover server costs"
                    )
                }

                Divider()

                Text(
                    text = "Every coffee makes a difference! 💙",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    openBuyMeACoffee(context, buyMeACoffeeUrl)
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Favorite, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Buy Me a Coffee ☕")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun SupportItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

/**
 * Support Manager - Handles when to show support dialog
 */
class SupportDialogManager(private val context: Context) {
    
    companion object {
        private const val PREFS_NAME = "support_prefs"
        private const val KEY_APP_OPENS = "app_opens"
        private const val KEY_LAST_SHOWN = "last_shown"
        private const val KEY_TIMES_SHOWN = "times_shown"
        private const val KEY_DONT_SHOW_AGAIN = "dont_show_again"
        
        private const val SHOW_AFTER_OPENS = 100 // Show after 100 app opens
        private const val SHOW_INTERVAL_DAYS = 30 // Show again after 30 days
        private const val MAX_TIMES_TO_SHOW = 2 // Show only 2 times total
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun incrementAppOpens() {
        val currentOpens = prefs.getInt(KEY_APP_OPENS, 0)
        prefs.edit().putInt(KEY_APP_OPENS, currentOpens + 1).apply()
    }

    fun shouldShowSupportDialog(): Boolean {
        // Don't show if user clicked "Don't show again"
        if (prefs.getBoolean(KEY_DONT_SHOW_AGAIN, false)) {
            return false
        }

        // Don't show if already shown MAX_TIMES_TO_SHOW times
        val timesShown = prefs.getInt(KEY_TIMES_SHOWN, 0)
        if (timesShown >= MAX_TIMES_TO_SHOW) {
            return false
        }

        val appOpens = prefs.getInt(KEY_APP_OPENS, 0)
        val lastShown = prefs.getLong(KEY_LAST_SHOWN, 0)
        val daysSinceLastShown = (System.currentTimeMillis() - lastShown) / (1000 * 60 * 60 * 24)

        // Show after SHOW_AFTER_OPENS opens, or after SHOW_INTERVAL_DAYS days
        return appOpens >= SHOW_AFTER_OPENS && 
               (lastShown == 0L || daysSinceLastShown >= SHOW_INTERVAL_DAYS)
    }

    fun markDialogShown() {
        val timesShown = prefs.getInt(KEY_TIMES_SHOWN, 0)
        prefs.edit()
            .putLong(KEY_LAST_SHOWN, System.currentTimeMillis())
            .putInt(KEY_APP_OPENS, 0) // Reset counter
            .putInt(KEY_TIMES_SHOWN, timesShown + 1)
            .apply()
    }

    fun dontShowAgain() {
        prefs.edit().putBoolean(KEY_DONT_SHOW_AGAIN, true).apply()
    }
    
    fun getTimesShown(): Int {
        return prefs.getInt(KEY_TIMES_SHOWN, 0)
    }
}

/**
 * Open Buy Me a Coffee URL
 */
fun openBuyMeACoffee(context: Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(url)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // Handle error - show toast
        android.widget.Toast.makeText(
            context,
            "Could not open browser",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }
}

/**
 * Support Button for Settings
 */
@Composable
fun SupportDeveloperButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Column {
                    Text(
                        text = "Support Development ☕",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Buy me a coffee if you enjoy the app!",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                    )
                }
            }
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}

/**
 * Rating Prompt Dialog
 */
@Composable
fun RatingPromptDialog(
    onDismiss: () -> Unit,
    onRate: () -> Unit,
    onLater: () -> Unit,
    onFeedback: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = {
            Text(
                text = "Enjoying Aux?",
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Your feedback helps improve the app!",
                    textAlign = TextAlign.Center
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    repeat(5) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onRate,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Star, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Rate on Play Store")
                }
                
                OutlinedButton(
                    onClick = onFeedback,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Feedback, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Send Feedback")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onLater) {
                Text("Maybe Later")
            }
        }
    )
}
