package com.aux.music.presentation.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.aux.music.data.model.Song
import com.aux.music.presentation.components.MusicVisualizer
import com.aux.music.presentation.components.ParticleBackground
import com.aux.music.presentation.viewmodel.MusicPlayerViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Full-screen Now Playing interface with lyrics and sleep timer
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    onBackClick: () -> Unit = {},
    playerViewModel: MusicPlayerViewModel = hiltViewModel()
) {
    val playerState by playerViewModel.playerState.collectAsState()
    var showLyrics by remember { mutableStateOf(false) }
    var showSleepTimer by remember { mutableStateOf(false) }
    var showPlaybackControls by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableStateOf(0L) }

    // Update current position
    LaunchedEffect(playerState.isPlaying) {
        while (playerState.isPlaying) {
            currentPosition = playerViewModel.getCurrentPosition()
            delay(1000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Now Playing") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Back")
                    }
                },
                actions = {
                    // Playback Controls (Speed, Pitch, Effects)
                    IconButton(onClick = { showPlaybackControls = true }) {
                        Icon(Icons.Default.Tune, contentDescription = "Playback Controls")
                    }
                    // Sleep Timer
                    IconButton(onClick = { showSleepTimer = true }) {
                        Icon(Icons.Default.Timer, contentDescription = "Sleep Timer")
                    }
                    // Bookmarks
                    IconButton(onClick = { showBookmarks = true }) {
                        Icon(Icons.Default.Bookmark, contentDescription = "Bookmarks")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        playerState.currentSong?.let { song ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Album Art
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    AsyncImage(
                        model = song.thumbnailUrl,
                        contentDescription = song.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))

                // Song Info
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = song.title,
                        style = MaterialTheme.typography.headlineSmall,
                        textAlign = TextAlign.Center,
                        maxLines = 2
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = song.artist,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Lyrics Button
                    OutlinedButton(
                        onClick = { showLyrics = !showLyrics },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showLyrics) "Lyrics" else "Lyrics")
                    }
                    
                    // Radio Button (NEW: InnerTube feature!)
                    OutlinedButton(
                        onClick = { 
                            playerViewModel.startRadio(song.youtubeId)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Radio,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Radio")
                    }
                }

                // Lyrics Display
                AnimatedVisibility(visible = showLyrics) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp)
                                .verticalScroll(rememberScrollState()),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Lyrics not available\n\nLyrics feature coming soon!\nWill display synchronized lyrics here.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Progress Bar
                Column {
                    Slider(
                        value = currentPosition.toFloat(),
                        onValueChange = { playerViewModel.seekTo(it.toLong()) },
                        valueRange = 0f..playerState.duration.toFloat(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatTime(currentPosition),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = formatTime(playerState.duration),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Playback Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Shuffle
                    IconButton(
                        onClick = { playerViewModel.toggleShuffle() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shuffle,
                            contentDescription = "Shuffle",
                            tint = if (playerState.shuffleEnabled)
                                MaterialTheme.colorScheme.primary
                            else
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Previous
                    IconButton(
                        onClick = { playerViewModel.skipToPrevious() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous",
                            modifier = Modifier.size(40.dp)
                        )
                    }

                    // Play/Pause
                    FloatingActionButton(
                        onClick = { playerViewModel.togglePlayPause() },
                        modifier = Modifier.size(72.dp)
                    ) {
                        Icon(
                            imageVector = if (playerState.isPlaying)
                                Icons.Default.Pause
                            else
                                Icons.Default.PlayArrow,
                            contentDescription = if (playerState.isPlaying) "Pause" else "Play",
                            modifier = Modifier.size(40.dp)
                        )
                    }

                    // Next
                    IconButton(
                        onClick = { playerViewModel.skipToNext() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next",
                            modifier = Modifier.size(40.dp)
                        )
                    }

                    // Repeat
                    IconButton(
                        onClick = { playerViewModel.toggleRepeatMode() }
                    ) {
                        Icon(
                            imageVector = when (playerState.repeatMode) {
                                com.aux.music.data.model.RepeatMode.ONE -> Icons.Default.RepeatOne
                                else -> Icons.Default.Repeat
                            },
                            contentDescription = "Repeat",
                            tint = if (playerState.repeatMode != com.aux.music.data.model.RepeatMode.OFF)
                                MaterialTheme.colorScheme.primary
                            else
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                
                // NEW: Music Visualizer (Visual Enhancement!)
                MusicVisualizer(
                    isPlaying = playerState.isPlaying,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .padding(top = 16.dp),
                    barCount = 30,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        } ?: Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No song playing")
        }
    }

    // Sleep Timer Dialog
    if (showSleepTimer) {
        SleepTimerDialog(
            onDismiss = { showSleepTimer = false },
            onSetTimer = { minutes, fadeOut ->
                playerViewModel.startSleepTimer(minutes, fadeOut)
                showSleepTimer = false
            }
        )
    }
    
    // Playback Controls Dialog (Speed, Pitch, Effects)
    if (showPlaybackControls) {
        PlaybackControlsDialog(
            onDismiss = { showPlaybackControls = false },
            currentSpeed = playerViewModel.playbackSpeed.collectAsState().value,
            currentPitch = playerViewModel.playbackPitch.collectAsState().value,
            bassBoost = playerViewModel.bassBoost.collectAsState().value,
            virtualizer = playerViewModel.virtualizer.collectAsState().value,
            reverb = playerViewModel.reverb.collectAsState().value,
            onSpeedChange = { playerViewModel.setPlaybackSpeed(it) },
            onPitchChange = { playerViewModel.setPlaybackPitch(it) },
            onBassBoostChange = { playerViewModel.setBassBoost(it) },
            onVirtualizerChange = { playerViewModel.setVirtualizer(it) },
            onReverbChange = { playerViewModel.setReverb(it) },
            onResetDefaults = {
                playerViewModel.resetPlaybackParameters()
                playerViewModel.resetAudioEffects()
            }
        )
    }
    
    // Bookmarks Dialog
    if (showBookmarks) {
        BookmarksDialog(
            onDismiss = { showBookmarks = false },
            bookmarks = playerViewModel.bookmarks.collectAsState().value,
            currentPosition = currentPosition,
            onAddBookmark = { playerViewModel.addBookmark(currentPosition) },
            onSeekToBookmark = { position ->
                playerViewModel.seekTo(position)
                showBookmarks = false
            },
            onDeleteBookmark = { playerViewModel.removeBookmark(it) }
        )
    }
}

@Composable
fun BookmarksDialog(
    onDismiss: () -> Unit,
    bookmarks: List<Long>,
    currentPosition: Long,
    onAddBookmark: () -> Unit,
    onSeekToBookmark: (Long) -> Unit,
    onDeleteBookmark: (Long) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Bookmark,
                contentDescription = null,
                modifier = Modifier.size(32.dp)
            )
        },
        title = { Text("Bookmarks") },
        text = {
            Column {
                Button(
                    onClick = onAddBookmark,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Add Bookmark at ${formatTime(currentPosition)}")
                }
                
                Spacer(Modifier.height(16.dp))
                
                if (bookmarks.isEmpty()) {
                    Text(
                        "No bookmarks yet",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(16.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.height(200.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(bookmarks.size) { index ->
                            val bookmark = bookmarks[index]
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSeekToBookmark(bookmark) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(formatTime(bookmark))
                                    IconButton(onClick = { onDeleteBookmark(bookmark) }) {
                                        Icon(Icons.Default.Delete, "Delete")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun SleepTimerDialog(
    onDismiss: () -> Unit,
    onSetTimer: (Int) -> Unit
) {
    var selectedMinutes by remember { mutableStateOf(15) }
    val timerOptions = listOf(5, 10, 15, 30, 45, 60)

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Timer,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = {
            Text("Sleep Timer")
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Music will stop after:",
                    style = MaterialTheme.typography.bodyMedium
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Timer options
                timerOptions.chunked(3).forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        row.forEach { minutes ->
                            FilterChip(
                                selected = selectedMinutes == minutes,
                                onClick = { selectedMinutes = minutes },
                                label = { Text("$minutes min") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Selected: $selectedMinutes minutes",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSetTimer(selectedMinutes) }
            ) {
                Text("Set Timer")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

fun formatTime(milliseconds: Long): String {
    val totalSeconds = milliseconds / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
