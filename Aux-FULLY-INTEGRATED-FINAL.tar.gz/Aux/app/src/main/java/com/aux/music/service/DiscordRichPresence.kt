package com.aux.music.service

import android.content.Context
import com.aux.music.data.model.Song
import com.aux.music.util.Constants
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import timber.log.Timber
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Discord Rich Presence Integration
 * Shows currently playing song as Discord status
 * 
 * Features:
 * - Display current song & artist
 * - Show elapsed time
 * - Custom app name
 * - Play/Pause status
 * - Album art
 */
@Singleton
class DiscordRichPresence @Inject constructor(
    private val context: Context
) {

    companion object {
        private const val DISCORD_GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json"
        
        // Discord Developer Portal - Create your app and get these
        private const val CLIENT_ID = "YOUR_DISCORD_CLIENT_ID" // Users will set this
        private const val CLIENT_SECRET = "YOUR_DISCORD_CLIENT_SECRET"
        
        // IPC for local Discord client
        private const val DISCORD_IPC_PIPE = "discord-ipc-0"
        
        // Presence update interval
        private const val UPDATE_INTERVAL_MS = 15000L // 15 seconds
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private var updateJob: Job? = null
    private var currentSong: Song? = null
    private var isPlaying: Boolean = false
    private var startTimestamp: Long = 0L
    private var isEnabled: Boolean = false

    /**
     * Initialize Discord Rich Presence
     */
    fun initialize(clientId: String, clientSecret: String) {
        if (clientId.isEmpty() || clientSecret.isEmpty()) {
            Timber.w("Discord credentials not set. Rich Presence disabled.")
            return
        }
        
        isEnabled = true
        Timber.d("Discord Rich Presence initialized")
    }

    /**
     * Update presence with current song
     */
    fun updatePresence(song: Song?, playing: Boolean, position: Long) {
        if (!isEnabled) return

        currentSong = song
        isPlaying = playing

        if (playing && song != null) {
            startTimestamp = System.currentTimeMillis() - position
            sendPresence()
        } else {
            clearPresence()
        }
    }

    /**
     * Start automatic presence updates
     */
    fun startUpdates(scope: CoroutineScope) {
        if (!isEnabled) return

        updateJob?.cancel()
        updateJob = scope.launch {
            while (isActive) {
                if (isPlaying && currentSong != null) {
                    sendPresence()
                }
                delay(UPDATE_INTERVAL_MS)
            }
        }
    }

    /**
     * Stop presence updates
     */
    fun stopUpdates() {
        updateJob?.cancel()
        clearPresence()
    }

    /**
     * Send presence to Discord
     */
    private fun sendPresence() {
        val song = currentSong ?: return

        try {
            val presence = createPresencePayload(song)
            sendToDiscord(presence)
            Timber.d("Discord presence updated: ${song.title}")
        } catch (e: Exception) {
            Timber.e(e, "Failed to update Discord presence")
        }
    }

    /**
     * Clear Discord presence
     */
    private fun clearPresence() {
        try {
            val clearPayload = JSONObject().apply {
                put("activity", JSONObject.NULL)
            }
            sendToDiscord(clearPayload.toString())
            Timber.d("Discord presence cleared")
        } catch (e: Exception) {
            Timber.e(e, "Failed to clear Discord presence")
        }
    }

    /**
     * Create Discord presence payload
     */
    private fun createPresencePayload(song: Song): String {
        val now = System.currentTimeMillis()
        val endTimestamp = if (isPlaying && song.duration > 0) {
            startTimestamp + song.duration
        } else {
            0L
        }

        val payload = JSONObject().apply {
            put("activity", JSONObject().apply {
                put("details", song.title) // Song title
                put("state", "by ${song.artist}") // Artist
                
                // Timestamps for elapsed time
                if (isPlaying) {
                    put("timestamps", JSONObject().apply {
                        put("start", startTimestamp)
                        if (endTimestamp > 0) {
                            put("end", endTimestamp)
                        }
                    })
                }

                // Album art as large image
                put("assets", JSONObject().apply {
                    if (song.thumbnailUrl.isNotEmpty()) {
                        put("large_image", song.thumbnailUrl)
                        put("large_text", song.title)
                    }
                    // App icon as small image
                    put("small_image", "aux_icon") // Upload to Discord
                    put("small_text", if (isPlaying) "Playing" else "Paused")
                })

                // Buttons (Discord Premium feature)
                put("buttons", org.json.JSONArray().apply {
                    // Listen along button (if song URL available)
                    put(JSONObject().apply {
                        put("label", "Listen on YouTube")
                        put("url", "https://youtube.com/watch?v=${song.youtubeId}")
                    })
                    // Support developer button
                    put(JSONObject().apply {
                        put("label", "Support Developer")
                        put("url", Constants.BUY_ME_A_COFFEE_URL)
                    })
                })

                // Application ID
                put("application_id", CLIENT_ID)

                // Type: Listening
                put("type", 2) // 0=Playing, 1=Streaming, 2=Listening, 3=Watching
            })
        }

        return payload.toString()
    }

    /**
     * Send payload to Discord
     * Uses Discord IPC for local client
     */
    private fun sendToDiscord(payload: String) {
        // This is a simplified version
        // Full implementation would use Discord IPC or WebSocket
        
        try {
            // For Android, we can use Discord's HTTP API
            // Or implement IPC if Discord app is installed
            
            val request = Request.Builder()
                .url("https://discord.com/api/v10/users/@me/settings")
                .addHeader("Authorization", "Bearer YOUR_USER_TOKEN") // User needs to authorize
                .addHeader("Content-Type", "application/json")
                .patch(payload.toRequestBody("application/json".toMediaType()))
                .build()

            // Note: This is a placeholder. Real implementation would:
            // 1. Check if Discord app is installed
            // 2. Use Discord IPC for local communication
            // 3. Or use OAuth for web-based presence
            
            Timber.d("Would send to Discord: $payload")
            
        } catch (e: Exception) {
            Timber.e(e, "Failed to send to Discord")
        }
    }

    /**
     * Check if Discord app is installed
     */
    fun isDiscordInstalled(): Boolean {
        return try {
            val pm = context.packageManager
            pm.getPackageInfo("com.discord", 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Open Discord app
     */
    fun openDiscord() {
        try {
            val intent = context.packageManager
                .getLaunchIntentForPackage("com.discord")
            intent?.let { context.startActivity(it) }
        } catch (e: Exception) {
            Timber.e(e, "Failed to open Discord")
        }
    }
}

/**
 * Discord Presence Builder
 * Helper for creating presence configurations
 */
class DiscordPresenceBuilder {
    private var details: String = ""
    private var state: String = ""
    private var largeImage: String? = null
    private var largeText: String? = null
    private var smallImage: String? = null
    private var smallText: String? = null
    private var startTimestamp: Long? = null
    private var endTimestamp: Long? = null
    private val buttons = mutableListOf<DiscordButton>()

    fun setDetails(text: String) = apply { details = text }
    fun setState(text: String) = apply { state = text }
    fun setLargeImage(url: String, text: String) = apply {
        largeImage = url
        largeText = text
    }
    fun setSmallImage(url: String, text: String) = apply {
        smallImage = url
        smallText = text
    }
    fun setStartTimestamp(timestamp: Long) = apply { startTimestamp = timestamp }
    fun setEndTimestamp(timestamp: Long) = apply { endTimestamp = timestamp }
    fun addButton(label: String, url: String) = apply {
        buttons.add(DiscordButton(label, url))
    }

    fun build(): String {
        val payload = JSONObject().apply {
            put("activity", JSONObject().apply {
                if (details.isNotEmpty()) put("details", details)
                if (state.isNotEmpty()) put("state", state)

                if (startTimestamp != null || endTimestamp != null) {
                    put("timestamps", JSONObject().apply {
                        startTimestamp?.let { put("start", it) }
                        endTimestamp?.let { put("end", it) }
                    })
                }

                if (largeImage != null || smallImage != null) {
                    put("assets", JSONObject().apply {
                        largeImage?.let { put("large_image", it) }
                        largeText?.let { put("large_text", it) }
                        smallImage?.let { put("small_image", it) }
                        smallText?.let { put("small_text", it) }
                    })
                }

                if (buttons.isNotEmpty()) {
                    put("buttons", org.json.JSONArray().apply {
                        buttons.forEach { button ->
                            put(JSONObject().apply {
                                put("label", button.label)
                                put("url", button.url)
                            })
                        }
                    })
                }

                put("type", 2) // Listening
            })
        }
        return payload.toString()
    }
}

data class DiscordButton(
    val label: String,
    val url: String
)

/**
 * Discord Presence Settings
 */
data class DiscordSettings(
    val enabled: Boolean = false,
    val clientId: String = "",
    val clientSecret: String = "",
    val showTimestamp: Boolean = true,
    val showAlbumArt: Boolean = true,
    val showButtons: Boolean = true,
    val updateInterval: Long = 15000L
)
