package com.aux.music.presentation.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Visual Enhancements for Aux Music Player
 * Modern animations, effects, and visual components
 */

/**
 * Animated Music Visualizer
 * Shows audio waveform animation while playing
 */
@Composable
fun MusicVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 40,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val animatedValues = remember { List(barCount) { Animatable(0.2f) } }
    
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            animatedValues.forEachIndexed { index, animatable ->
                kotlinx.coroutines.launch {
                    animatable.animateTo(
                        targetValue = 1f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(
                                durationMillis = (400..800).random(),
                                delayMillis = index * 20,
                                easing = FastOutSlowInEasing
                            ),
                            repeatMode = RepeatMode.Reverse
                        )
                    )
                }
            }
        } else {
            animatedValues.forEach { it.snapTo(0.2f) }
        }
    }
    
    Canvas(modifier = modifier) {
        val barWidth = size.width / (barCount * 2)
        val spacing = barWidth
        
        animatedValues.forEachIndexed { index, animatable ->
            val height = size.height * animatable.value
            val x = index * (barWidth + spacing) + spacing
            
            drawRoundRect(
                color = color.copy(alpha = 0.8f),
                topLeft = Offset(x, (size.height - height) / 2),
                size = androidx.compose.ui.geometry.Size(barWidth, height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2)
            )
        }
    }
}

/**
 * Circular Progress with Glow Effect
 * Beautiful progress indicator for current song
 */
@Composable
fun GlowingCircularProgress(
    progress: Float,
    modifier: Modifier = Modifier,
    strokeWidth: Float = 12f,
    glowRadius: Float = 20f,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )
    
    Canvas(modifier = modifier) {
        val diameter = size.minDimension
        val radius = diameter / 2
        val center = Offset(size.width / 2, size.height / 2)
        
        // Glow effect
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    color.copy(alpha = glowAlpha),
                    Color.Transparent
                ),
                center = center,
                radius = radius + glowRadius
            ),
            radius = radius + glowRadius,
            center = center
        )
        
        // Background circle
        drawCircle(
            color = color.copy(alpha = 0.1f),
            radius = radius - strokeWidth / 2,
            center = center,
            style = Stroke(width = strokeWidth)
        )
        
        // Progress arc
        drawArc(
            color = color,
            startAngle = -90f,
            sweepAngle = progress * 360f,
            useCenter = false,
            topLeft = Offset(
                center.x - radius + strokeWidth / 2,
                center.y - radius + strokeWidth / 2
            ),
            size = androidx.compose.ui.geometry.Size(
                (radius - strokeWidth / 2) * 2,
                (radius - strokeWidth / 2) * 2
            ),
            style = Stroke(
                width = strokeWidth,
                cap = StrokeCap.Round
            )
        )
    }
}

/**
 * Particle Effect Background
 * Floating particles for ambient effect
 */
@Composable
fun ParticleBackground(
    modifier: Modifier = Modifier,
    particleCount: Int = 30,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val particles = remember {
        List(particleCount) {
            ParticleState(
                x = (0..100).random() / 100f,
                y = (0..100).random() / 100f,
                size = (2..8).random().toFloat(),
                speed = (1..3).random() / 100f,
                alpha = (0.1f..0.4f).random()
            )
        }
    }
    
    var time by remember { mutableFloatStateOf(0f) }
    
    LaunchedEffect(Unit) {
        while (true) {
            withFrameMillis {
                time += 0.016f // ~60fps
            }
        }
    }
    
    Canvas(modifier = modifier) {
        particles.forEach { particle ->
            val currentY = ((particle.y + particle.speed * time) % 1f) * size.height
            val currentX = particle.x * size.width
            
            drawCircle(
                color = color.copy(alpha = particle.alpha),
                radius = particle.size,
                center = Offset(currentX, currentY)
            )
        }
    }
}

private data class ParticleState(
    val x: Float,
    val y: Float,
    val size: Float,
    val speed: Float,
    val alpha: Float
)

/**
 * Pulsing Like Button
 * Animated like/favorite button with heart shape
 */
@Composable
fun PulsingLikeButton(
    isLiked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (isLiked) 1.2f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "like_scale"
    )
    
    val color by animateColorAsState(
        targetValue = if (isLiked) 
            Color(0xFFE91E63) // Pink for liked
        else 
            MaterialTheme.colorScheme.onSurfaceVariant,
        label = "like_color"
    )
    
    IconButton(
        onClick = onClick,
        modifier = modifier.scale(scale)
    ) {
        Icon(
            imageVector = if (isLiked) 
                androidx.compose.material.icons.Icons.Default.Favorite 
            else 
                androidx.compose.material.icons.Icons.Default.FavoriteBorder,
            contentDescription = if (isLiked) "Unlike" else "Like",
            tint = color
        )
    }
}

/**
 * Gradient Text
 * Beautiful gradient colored text
 */
@Composable
fun GradientText(
    text: String,
    gradient: Brush,
    style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.displayLarge,
    modifier: Modifier = Modifier
) {
    Text(
        text = text,
        style = style.copy(
            brush = gradient
        ),
        modifier = modifier
    )
}

/**
 * Animated Album Art
 * Rotating album art with glow effect
 */
@Composable
fun AnimatedAlbumArt(
    imageUrl: String?,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val rotation by rememberInfiniteTransition(label = "album_rotation").animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    
    val actualRotation = if (isPlaying) rotation else 0f
    
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        // Glow background
        Box(
            modifier = Modifier
                .fillMaxSize()
                .blur(20.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                            Color.Transparent
                        )
                    )
                )
        )
        
        // Album art
        AsyncImage(
            model = imageUrl,
            contentDescription = "Album Art",
            modifier = Modifier
                .fillMaxSize(0.8f)
                .rotate(actualRotation)
                .clip(CircleShape),
            contentScale = ContentScale.Crop
        )
    }
}

/**
 * Wave Animation Background
 * Smooth wave animation for backgrounds
 */
@Composable
fun WaveBackground(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary
) {
    var phase by remember { mutableFloatStateOf(0f) }
    
    LaunchedEffect(Unit) {
        while (true) {
            withFrameMillis {
                phase += 0.02f
            }
        }
    }
    
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val waveHeight = height * 0.3f
        val wavelength = width / 2
        
        val path = Path().apply {
            moveTo(0f, height / 2)
            
            for (x in 0..width.toInt() step 10) {
                val y = height / 2 + 
                    sin((x / wavelength * 2 * PI + phase).toFloat()) * waveHeight
                lineTo(x.toFloat(), y)
            }
            
            lineTo(width, height)
            lineTo(0f, height)
            close()
        }
        
        drawPath(
            path = path,
            brush = Brush.verticalGradient(
                colors = listOf(
                    color.copy(alpha = 0.3f),
                    color.copy(alpha = 0.1f)
                )
            )
        )
    }
}

/**
 * Shimmer Loading Effect
 * Beautiful loading placeholder
 */
@Composable
fun ShimmerLoading(
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_translate"
    )
    
    Box(
        modifier = modifier
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.surfaceVariant,
                        MaterialTheme.colorScheme.surface,
                        MaterialTheme.colorScheme.surfaceVariant
                    ),
                    start = Offset(translateAnim - 1000f, 0f),
                    end = Offset(translateAnim, 0f)
                )
            )
    )
}

/**
 * Glassmorphism Card
 * Modern glass effect card
 */
@Composable
fun GlassmorphismCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.1f),
                            Color.White.copy(alpha = 0.05f)
                        )
                    )
                )
        ) {
            content()
        }
    }
}

/**
 * Bouncing Button
 * Button with bounce animation on tap
 */
@Composable
fun BouncingButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable RowScope.() -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "bounce_scale"
    )
    
    Button(
        onClick = {
            isPressed = true
            onClick()
            isPressed = false
        },
        modifier = modifier.scale(scale),
        content = content
    )
}
