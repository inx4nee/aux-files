package com.aux.music.data.repository

import com.aux.music.data.api.InnerTubeApi
import com.aux.music.data.model.Song
import com.aux.music.util.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Hybrid Music Repository
 * 
 * Architecture:
 * - NewPipe Extractor: For URL extraction and streaming (ONLY)
 * - InnerTube API: For recommendations, next songs, personalization
 * 
 * Why this approach:
 * - NewPipe: Reliable, proven URL extraction
 * - InnerTube: Better recommendations, smart AI, personalization
 * - Best of both worlds!
 */
@Singleton
class HybridMusicRepository @Inject constructor(
    private val innerTubeApi: InnerTubeApi
) {

    private val youtubeService = ServiceList.YouTube

    /**
     * STREAMING: Uses NewPipe
     * Get actual playable stream URL for a video
     */
    suspend fun getStreamUrl(videoId: String): Resource<String> = withContext(Dispatchers.IO) {
        try {
            Timber.d("Getting stream URL via NewPipe for: $videoId")
            
            val streamExtractor = youtubeService.getStreamExtractor(
                "https://youtube.com/watch?v=$videoId"
            )
            streamExtractor.fetchPage()

            // Get best audio stream
            val audioStream = streamExtractor.audioStreams
                .maxByOrNull { it.averageBitrate }
                ?: return@withContext Resource.Error("No audio stream found")

            val streamUrl = audioStream.content
                ?: return@withContext Resource.Error("Stream URL is null")

            Timber.d("✅ NewPipe: Got stream URL")
            Resource.Success(streamUrl)

        } catch (e: Exception) {
            Timber.e(e, "❌ NewPipe: Failed to get stream URL")
            Resource.Error(e.message ?: "Failed to get stream URL")
        }
    }

    /**
     * SEARCH: Uses NewPipe
     * Search for songs/videos
     */
    suspend fun search(query: String): Resource<List<Song>> = withContext(Dispatchers.IO) {
        try {
            Timber.d("Searching via NewPipe: $query")
            
            val searchExtractor = youtubeService.getSearchExtractor(query)
            searchExtractor.fetchPage()

            val songs = searchExtractor.initialPage.items
                .filterIsInstance<StreamInfoItem>()
                .mapNotNull { item ->
                    try {
                        Song(
                            id = item.url.substringAfterLast("="),
                            title = item.name,
                            artist = item.uploaderName ?: "Unknown",
                            duration = item.duration * 1000L,
                            thumbnailUrl = item.thumbnailUrl ?: "",
                            youtubeId = item.url.substringAfterLast("="),
                            source = "YOUTUBE"
                        )
                    } catch (e: Exception) {
                        Timber.w(e, "Failed to parse search item")
                        null
                    }
                }

            Timber.d("✅ NewPipe: Found ${songs.size} results")
            Resource.Success(songs)

        } catch (e: Exception) {
            Timber.e(e, "❌ NewPipe: Search failed")
            Resource.Error(e.message ?: "Search failed")
        }
    }

    /**
     * RECOMMENDATIONS: Uses InnerTube API
     * Get smart, personalized next songs
     */
    suspend fun getNextSongs(videoId: String): Resource<List<Song>> = withContext(Dispatchers.IO) {
        try {
            Timber.d("Getting next songs via InnerTube for: $videoId")
            
            val result = innerTubeApi.getNext(videoId)
            
            if (result.isSuccess) {
                val innerTubeSongs = result.getOrNull()?.songs ?: emptyList()
                val songs = innerTubeSongs.map { convertInnerTubeToSong(it) }
                
                Timber.d("✅ InnerTube: Got ${songs.size} next songs")
                Resource.Success(songs)
            } else {
                Timber.e("❌ InnerTube: Failed to get next songs")
                Resource.Error(result.exceptionOrNull()?.message ?: "Failed")
            }

        } catch (e: Exception) {
            Timber.e(e, "❌ InnerTube: Error getting next songs")
            Resource.Error(e.message ?: "Failed to get recommendations")
        }
    }

    /**
     * RADIO/MIX: Uses InnerTube API
     * Create endless mix based on song
     */
    suspend fun createRadio(videoId: String): Resource<List<Song>> = withContext(Dispatchers.IO) {
        try {
            Timber.d("Creating radio via InnerTube for: $videoId")
            
            val result = innerTubeApi.getRadio(videoId)
            
            if (result.isSuccess) {
                val radioSongs = result.getOrNull()?.songs ?: emptyList()
                val songs = radioSongs.map { convertInnerTubeToSong(it) }
                
                Timber.d("✅ InnerTube: Created radio with ${songs.size} songs")
                Resource.Success(songs)
            } else {
                Timber.e("❌ InnerTube: Failed to create radio")
                Resource.Error(result.exceptionOrNull()?.message ?: "Failed")
            }

        } catch (e: Exception) {
            Timber.e(e, "❌ InnerTube: Error creating radio")
            Resource.Error(e.message ?: "Failed to create radio")
        }
    }

    /**
     * PERSONALIZED RECOMMENDATIONS: Uses InnerTube API
     * Get personalized home feed recommendations
     */
    suspend fun getRecommendations(): Resource<List<RecommendationSection>> = 
        withContext(Dispatchers.IO) {
        try {
            Timber.d("Getting personalized recommendations via InnerTube")
            
            val result = innerTubeApi.getRecommendations()
            
            if (result.isSuccess) {
                val sections = result.getOrNull()?.sections ?: emptyList()
                
                // Convert to our format
                val recommendationSections = sections.map { section ->
                    RecommendationSection(
                        title = section.title,
                        songs = section.songs.map { convertInnerTubeToSong(it) }
                    )
                }
                
                Timber.d("✅ InnerTube: Got ${sections.size} recommendation sections")
                Resource.Success(recommendationSections)
            } else {
                Timber.e("❌ InnerTube: Failed to get recommendations")
                Resource.Error(result.exceptionOrNull()?.message ?: "Failed")
            }

        } catch (e: Exception) {
            Timber.e(e, "❌ InnerTube: Error getting recommendations")
            Resource.Error(e.message ?: "Failed to get recommendations")
        }
    }

    /**
     * Convert InnerTube song to our Song model
     */
    private fun convertInnerTubeToSong(innerTubeSong: com.aux.music.data.api.InnerTubeSong): Song {
        return Song(
            id = innerTubeSong.videoId,
            title = innerTubeSong.title,
            artist = innerTubeSong.artist,
            duration = innerTubeSong.duration,
            thumbnailUrl = innerTubeSong.thumbnailUrl,
            youtubeId = innerTubeSong.videoId,
            source = "YOUTUBE"
        )
    }

    /**
     * Get song details (uses NewPipe for reliability)
     */
    suspend fun getSongDetails(videoId: String): Resource<Song> = withContext(Dispatchers.IO) {
        try {
            val streamExtractor = youtubeService.getStreamExtractor(
                "https://youtube.com/watch?v=$videoId"
            )
            streamExtractor.fetchPage()

            val song = Song(
                id = videoId,
                title = streamExtractor.name,
                artist = streamExtractor.uploaderName ?: "Unknown",
                duration = streamExtractor.length * 1000L,
                thumbnailUrl = streamExtractor.thumbnailUrl ?: "",
                youtubeId = videoId,
                source = "YOUTUBE"
            )

            Resource.Success(song)

        } catch (e: Exception) {
            Timber.e(e, "Failed to get song details")
            Resource.Error(e.message ?: "Failed to get song details")
        }
    }
}

/**
 * Recommendation section for home feed
 */
data class RecommendationSection(
    val title: String,
    val songs: List<Song>
)
