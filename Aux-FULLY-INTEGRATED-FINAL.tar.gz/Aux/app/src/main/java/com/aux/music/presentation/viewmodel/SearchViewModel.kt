package com.aux.music.presentation.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aux.music.data.model.Song
import com.aux.music.data.repository.MusicRepository
import com.aux.music.data.repository.YouTubeRepositoryOptimized
import com.aux.music.util.*
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Optimized SearchViewModel with error handling, debouncing, and pagination
 */
@HiltViewModel
class SearchViewModelOptimized @Inject constructor(
    @ApplicationContext private val context: Context,
    private val youTubeRepository: YouTubeRepositoryOptimized,
    private val musicRepository: MusicRepository
) : ViewModel() {

    // Search state
    private val _searchState = MutableStateFlow<SearchState>(SearchState.Idle)
    val searchState: StateFlow<SearchState> = _searchState.asStateFlow()

    // Search results
    private val _searchResults = MutableStateFlow<List<Song>>(emptyList())
    val searchResults: StateFlow<List<Song>> = _searchResults.asStateFlow()

    // Error state
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Debouncer for search queries
    private val searchDebouncer = Debouncer(delayMillis = 500L)
    private var searchJob: Job? = null

    // Pagination
    private var nextPageToken: String? = null
    private var isLoadingMore = false

    init {
        // Observe search query changes with debouncing
        viewModelScope.launch {
            searchQuery
                .debounce(500L)
                .filter { it.isNotBlank() && it.length >= 2 }
                .distinctUntilChanged()
                .collect { query ->
                    performSearch(query)
                }
        }
    }

    /**
     * Update search query
     */
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
            clearSearch()
        }
    }

    /**
     * Perform search with error handling
     */
    fun performSearch(query: String) {
        if (!context.isNetworkAvailable()) {
            _error.value = "No internet connection"
            _searchState.value = SearchState.Error("No internet connection")
            return
        }

        // Cancel previous search
        searchJob?.cancel()

        searchJob = viewModelScope.launch(coroutineExceptionHandler) {
            try {
                _searchState.value = SearchState.Loading
                _error.value = null
                nextPageToken = null

                Timber.d("Searching for: $query")

                when (val result = youTubeRepository.searchSongs(query)) {
                    is Resource.Success -> {
                        val searchResult = result.data
                        if (searchResult != null) {
                            _searchResults.value = searchResult.songs
                            nextPageToken = searchResult.nextPageToken
                            
                            if (searchResult.songs.isEmpty()) {
                                _searchState.value = SearchState.Empty
                            } else {
                                _searchState.value = SearchState.Success
                            }
                            
                            Timber.d("Search completed: ${searchResult.songs.size} results")
                        } else {
                            _searchState.value = SearchState.Empty
                        }
                    }
                    is Resource.Error -> {
                        val errorMessage = result.message ?: "Search failed"
                        _error.value = errorMessage
                        _searchState.value = SearchState.Error(errorMessage)
                        Timber.e("Search error: $errorMessage")
                    }
                    is Resource.Loading -> {
                        _searchState.value = SearchState.Loading
                    }
                }
            } catch (e: Exception) {
                val errorMessage = ErrorHandler.getErrorMessage(e)
                _error.value = errorMessage
                _searchState.value = SearchState.Error(errorMessage)
                Timber.e(e, "Search exception")
            }
        }
    }

    /**
     * Load more results (pagination)
     */
    fun loadMore() {
        if (isLoadingMore || nextPageToken == null) return

        isLoadingMore = true
        viewModelScope.launch(coroutineExceptionHandler) {
            try {
                val query = _searchQuery.value
                
                when (val result = youTubeRepository.searchSongs(query, nextPageToken)) {
                    is Resource.Success -> {
                        val searchResult = result.data
                        if (searchResult != null) {
                            val currentResults = _searchResults.value
                            _searchResults.value = currentResults + searchResult.songs
                            nextPageToken = searchResult.nextPageToken
                            
                            Timber.d("Loaded more: ${searchResult.songs.size} results")
                        }
                    }
                    is Resource.Error -> {
                        Timber.e("Failed to load more results: ${result.message}")
                    }
                    else -> { /* Ignore */ }
                }
            } catch (e: Exception) {
                Timber.e(e, "Load more exception")
            } finally {
                isLoadingMore = false
            }
        }
    }

    /**
     * Add song to library with error handling
     */
    fun addSongToLibrary(song: Song) {
        viewModelScope.launch(coroutineExceptionHandler) {
            try {
                when (val result = safeDatabaseCall {
                    musicRepository.insertSong(song)
                }) {
                    is Resource.Success -> {
                        Timber.d("Added song to library: ${song.title}")
                    }
                    is Resource.Error -> {
                        _error.value = "Failed to add song to library"
                        Timber.e("Failed to add song to library: ${result.message}")
                    }
                    else -> { /* Ignore */ }
                }
            } catch (e: Exception) {
                Timber.e(e, "Exception adding song to library")
            }
        }
    }

    /**
     * Clear search results
     */
    fun clearSearch() {
        searchJob?.cancel()
        _searchResults.value = emptyList()
        _searchState.value = SearchState.Idle
        _error.value = null
        nextPageToken = null
        Timber.d("Search cleared")
    }

    /**
     * Dismiss error
     */
    fun dismissError() {
        _error.value = null
    }

    /**
     * Retry last search
     */
    fun retrySearch() {
        val query = _searchQuery.value
        if (query.isNotBlank()) {
            performSearch(query)
        }
    }

    override fun onCleared() {
        super.onCleared()
        searchJob?.cancel()
        searchDebouncer.cancel()
        Timber.d("SearchViewModel cleared")
    }
}

/**
 * Search state sealed class
 */
sealed class SearchState {
    object Idle : SearchState()
    object Loading : SearchState()
    object Success : SearchState()
    object Empty : SearchState()
    data class Error(val message: String) : SearchState()
}
