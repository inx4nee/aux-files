package com.aux.music.presentation.viewmodel

import android.content.ComponentName
import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.aux.music.data.api.GeniusLyricsService
import com.aux.music.data.api.fetchGeniusLyrics
import com.aux.music.data.api.InnerTubeApi
import com.aux.music.data.model.PlayerState
import com.aux.music.data.model.RepeatMode
import com.aux.music.data.model.Song
import com.aux.music.data.repository.MusicRepository
import com.aux.music.data.repository.YouTubeRepositoryOptimized
import com.aux.music.data.repository.HybridMusicRepository
import com.aux.music.service.MusicPlayerService
import com.aux.music.service.DiscordRichPresence
import com.aux.music.util.ApiConfig
import com.aux.music.util.Resource
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Fully featured ViewModel with all 29 features integrated
 * Now includes InnerTube API and Discord Rich Presence
 */
@HiltViewModel
class MusicPlayerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val youTubeRepository: YouTubeRepositoryOptimized,
    private val musicRepository: MusicRepository,
    private val hybridRepository: HybridMusicRepository,
    private val innerTubeApi: InnerTubeApi,
    private val discordRichPresence: DiscordRichPresence
) : ViewModel() {

    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()
    
    // InnerTube: Next songs from AI recommendations
    private val _nextSongs = MutableStateFlow<List<Song>>(emptyList())
    val nextSongs: StateFlow<List<Song>> = _nextSongs.asStateFlow()
    
    // InnerTube: Personalized recommendations
    private val _recommendations = MutableStateFlow<List<com.aux.music.data.repository.RecommendationSection>>(emptyList())
    val recommendations: StateFlow<List<com.aux.music.data.repository.RecommendationSection>> = _recommendations.asStateFlow()

    // Speed & Pitch Control
    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()
    
    private val _playbackPitch = MutableStateFlow(1.0f)
    val playbackPitch: StateFlow<Float> = _playbackPitch.asStateFlow()

    // Audio Effects
    private val _bassBoost = MutableStateFlow(0)
    val bassBoost: StateFlow<Int> = _bassBoost.asStateFlow()
    
    private val _virtualizer = MutableStateFlow(0)
    val virtualizer: StateFlow<Int> = _virtualizer.asStateFlow()
    
    private val _reverb = MutableStateFlow(0)
    val reverb: StateFlow<Int> = _reverb.asStateFlow()

    // Audio effects objects
    private var bassBoostEffect: BassBoost? = null
    private var virtualizerEffect: Virtualizer? = null
    private var reverbEffect: PresetReverb? = null

    // Sleep Timer
    private val _sleepTimerMinutes = MutableStateFlow(0)
    val sleepTimerMinutes: StateFlow<Int> = _sleepTimerMinutes.asStateFlow()
    
    private var sleepTimerJob: kotlinx.coroutines.Job? = null

    // Bookmarks
    private val _bookmarks = MutableStateFlow<List<Bookmark>>(emptyList())
    val bookmarks: StateFlow<List<Bookmark>> = _bookmarks.asStateFlow()

    private var mediaController: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    init {
        initializeMediaController()
        loadBookmarks()
        
        // Initialize Genius API with key from config
        if (ApiConfig.isGeniusApiConfigured()) {
            GeniusLyricsService.setApiKey(ApiConfig.GENIUS_API_KEY)
            Timber.d("Genius API initialized")
        } else {
            Timber.w("Genius API key not configured")
        }
    }

    private fun initializeMediaController() {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, MusicPlayerService::class.java)
        )

        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture?.addListener(
            {
                mediaController = controllerFuture?.get()
                setupPlayerListener()
                initializeAudioEffects()
            },
            MoreExecutors.directExecutor()
        )
    }

    private fun initializeAudioEffects() {
        try {
            val audioSessionId = mediaController?.audioSessionId ?: 0
            
            bassBoostEffect = BassBoost(0, audioSessionId).apply {
                enabled = true
            }
            
            virtualizerEffect = Virtualizer(0, audioSessionId).apply {
                enabled = true
            }
            
            reverbEffect = PresetReverb(0, audioSessionId).apply {
                enabled = true
            }
            
            Timber.d("Audio effects initialized successfully")
        } catch (e: Exception) {
            Timber.e(e, "Failed to initialize audio effects")
        }
    }

    private fun setupPlayerListener() {
        mediaController?.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _playerState.value = _playerState.value.copy(isPlaying = isPlaying)
                
                // Track listening history
                if (isPlaying) {
                    _playerState.value.currentSong?.let { song ->
                        trackListeningHistory(song)
                    }
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // Update current song when track changes
                updateCurrentSongFromMediaItem()
            }
        })
    }

    // FEATURE 1: Queue Management (Enhanced with InnerTube auto-queue)
    fun playQueue(songs: List<Song>, startIndex: Int = 0) {
        viewModelScope.launch {
            try {
                _playerState.value = _playerState.value.copy(
                    queue = songs,
                    currentIndex = startIndex
                )

                songs.forEach { song ->
                    when (val result = youTubeRepository.getStreamUrl(song.youtubeId)) {
                        is Resource.Success -> {
                            val mediaItem = MediaItem.Builder()
                                .setUri(result.data)
                                .setMediaId(song.id)
                                .build()
                            mediaController?.addMediaItem(mediaItem)
                        }
                        is Resource.Error -> {
                            Timber.e("Failed to get stream URL: ${result.message}")
                        }
                        else -> {}
                    }
                }

                mediaController?.prepare()
                if (startIndex > 0) {
                    mediaController?.seekToDefaultPosition(startIndex)
                }
                mediaController?.play()
                
                // NEW: Auto-queue next songs using InnerTube
                if (songs.isNotEmpty()) {
                    val currentSong = songs[startIndex]
                    autoQueueNextSongs(currentSong.youtubeId)
                    
                    // Update Discord Rich Presence
                    discordRichPresence.updatePresence(
                        song = currentSong,
                        playing = true,
                        position = 0L
                    )
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to play queue")
            }
        }
    }
    
    /**
     * NEW FEATURE: Auto-queue next songs using InnerTube AI
     */
    private fun autoQueueNextSongs(videoId: String) {
        viewModelScope.launch {
            try {
                when (val result = hybridRepository.getNextSongs(videoId)) {
                    is Resource.Success -> {
                        val nextSongs = result.data.take(10) // Get top 10 recommendations
                        _nextSongs.value = nextSongs
                        
                        // Add to queue
                        nextSongs.forEach { song ->
                            addToQueue(song)
                        }
                        
                        Timber.d("✅ InnerTube: Auto-queued ${nextSongs.size} songs")
                    }
                    is Resource.Error -> {
                        Timber.w("⚠️ InnerTube: Failed to auto-queue: ${result.message}")
                    }
                    else -> {}
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to auto-queue next songs")
            }
        }
    }
    
    /**
     * NEW FEATURE: Start radio/mix based on current song
     */
    fun startRadio(videoId: String) {
        viewModelScope.launch {
            try {
                when (val result = hybridRepository.createRadio(videoId)) {
                    is Resource.Success -> {
                        val radioSongs = result.data
                        playQueue(radioSongs, 0)
                        Timber.d("✅ InnerTube: Started radio with ${radioSongs.size} songs")
                    }
                    is Resource.Error -> {
                        Timber.e("⚠️ InnerTube: Failed to create radio: ${result.message}")
                    }
                    else -> {}
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to start radio")
            }
        }
    }
    
    /**
     * NEW FEATURE: Load personalized recommendations
     */
    fun loadRecommendations() {
        viewModelScope.launch {
            try {
                when (val result = hybridRepository.getRecommendations()) {
                    is Resource.Success -> {
                        _recommendations.value = result.data
                        Timber.d("✅ InnerTube: Loaded ${result.data.size} recommendation sections")
                    }
                    is Resource.Error -> {
                        Timber.e("⚠️ InnerTube: Failed to load recommendations: ${result.message}")
                    }
                    else -> {}
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to load recommendations")
            }
        }
    }
    
    /**
     * Enhanced addToQueue with optional auto-fetch
     */
    fun addToQueue(song: Song, autoFetch: Boolean = false) {
        val currentQueue = _playerState.value.queue.toMutableList()
        currentQueue.add(song)
        _playerState.value = _playerState.value.copy(queue = currentQueue)
        
        if (autoFetch) {
            viewModelScope.launch {
                when (val result = youTubeRepository.getStreamUrl(song.youtubeId)) {
                    is Resource.Success -> {
                        val mediaItem = MediaItem.Builder()
                            .setUri(result.data)
                            .setMediaId(song.id)
                            .build()
                        mediaController?.addMediaItem(mediaItem)
                    }
                    is Resource.Error -> {
                        Timber.e("Failed to add to queue: ${result.message}")
                    }
                    else -> {}
                }
            }
        }
    }

    fun removeFromQueue(index: Int) {
        val currentQueue = _playerState.value.queue.toMutableList()
        if (index in currentQueue.indices) {
            currentQueue.removeAt(index)
            _playerState.value = _playerState.value.copy(queue = currentQueue)
            mediaController?.removeMediaItem(index)
        }
    }

    fun clearQueue() {
        _playerState.value = _playerState.value.copy(queue = emptyList())
        mediaController?.clearMediaItems()
    }

    // FEATURE 2: Speed & Pitch Control
    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        val currentPitch = _playbackPitch.value
        mediaController?.playbackParameters = PlaybackParameters(speed, currentPitch)
        Timber.d("Playback speed set to: $speed")
    }

    fun setPlaybackPitch(pitch: Float) {
        _playbackPitch.value = pitch
        val currentSpeed = _playbackSpeed.value
        mediaController?.playbackParameters = PlaybackParameters(currentSpeed, pitch)
        Timber.d("Playback pitch set to: $pitch")
    }

    fun resetPlaybackParameters() {
        setPlaybackSpeed(1.0f)
        setPlaybackPitch(1.0f)
    }

    // FEATURE 4: Audio Effects
    fun setBassBoost(strength: Int) {
        _bassBoost.value = strength
        try {
            bassBoostEffect?.setStrength(strength.toShort())
            Timber.d("Bass boost set to: $strength")
        } catch (e: Exception) {
            Timber.e(e, "Failed to set bass boost")
        }
    }

    fun setVirtualizer(strength: Int) {
        _virtualizer.value = strength
        try {
            virtualizerEffect?.setStrength(strength.toShort())
            Timber.d("Virtualizer set to: $strength")
        } catch (e: Exception) {
            Timber.e(e, "Failed to set virtualizer")
        }
    }

    fun setReverb(level: Int) {
        _reverb.value = level
        try {
            // Map 0-100 to preset values 0-6
            val preset = (level * 6 / 100).coerceIn(0, 6).toShort()
            reverbEffect?.preset = preset
            Timber.d("Reverb set to: $level (preset: $preset)")
        } catch (e: Exception) {
            Timber.e(e, "Failed to set reverb")
        }
    }

    fun resetAudioEffects() {
        setBassBoost(0)
        setVirtualizer(0)
        setReverb(0)
    }

    // FEATURE 15: Advanced Sleep Timer
    fun startSleepTimer(minutes: Int, fadeOut: Boolean = true) {
        sleepTimerJob?.cancel()
        _sleepTimerMinutes.value = minutes

        sleepTimerJob = viewModelScope.launch {
            val endTime = System.currentTimeMillis() + (minutes * 60 * 1000L)

            while (System.currentTimeMillis() < endTime) {
                kotlinx.coroutines.delay(1000)

                // Update remaining time
                val remaining = ((endTime - System.currentTimeMillis()) / 60000).toInt()
                _sleepTimerMinutes.value = remaining

                // Fade out in last 30 seconds
                if (fadeOut) {
                    val remainingMs = endTime - System.currentTimeMillis()
                    if (remainingMs < 30000 && remainingMs > 0) {
                        val volume = (remainingMs / 30000f).coerceIn(0f, 1f)
                        mediaController?.volume = volume
                    }
                }
            }

            // Timer expired
            mediaController?.pause()
            mediaController?.volume = 1.0f
            _sleepTimerMinutes.value = 0
            Timber.d("Sleep timer expired")
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _sleepTimerMinutes.value = 0
        mediaController?.volume = 1.0f
        Timber.d("Sleep timer cancelled")
    }

    fun extendSleepTimer(additionalMinutes: Int) {
        val currentRemaining = _sleepTimerMinutes.value
        if (currentRemaining > 0) {
            startSleepTimer(currentRemaining + additionalMinutes)
        }
    }

    // FEATURE 17: Bookmarks
    private fun loadBookmarks() {
        viewModelScope.launch {
            _playerState.value.currentSong?.let { song ->
                musicRepository.getBookmarksForSong(song.id).collect { bookmarks ->
                    _bookmarks.value = bookmarks
                }
            }
        }
    }

    // FEATURE 16: Lyrics Sync
    suspend fun fetchLyrics(song: Song): String? {
        if (!ApiConfig.isGeniusApiConfigured()) {
            Timber.w("Cannot fetch lyrics: Genius API key not configured")
            return null
        }
        
        return try {
            Timber.d("Fetching lyrics for: ${song.artist} - ${song.title}")
            val lyrics = fetchGeniusLyrics(song.artist, song.title)
            
            if (lyrics != null) {
                Timber.d("Successfully fetched lyrics (${lyrics.length} chars)")
            } else {
                Timber.d("No lyrics found for: ${song.title}")
            }
            
            lyrics
        } catch (e: Exception) {
            Timber.e(e, "Error fetching lyrics")
            null
        }
    }

    fun addBookmark(position: Long, note: String? = null) {
        viewModelScope.launch {
            _playerState.value.currentSong?.let { song ->
                val bookmark = Bookmark(
                    songId = song.id,
                    position = position,
                    note = note,
                    createdAt = System.currentTimeMillis()
                )
                musicRepository.insertBookmark(bookmark)
                Timber.d("Bookmark added at position: $position")
            }
        }
    }

    fun deleteBookmark(bookmark: Bookmark) {
        viewModelScope.launch {
            musicRepository.deleteBookmark(bookmark)
            Timber.d("Bookmark deleted")
        }
    }

    fun seekToBookmark(bookmark: Bookmark) {
        seekTo(bookmark.position)
    }

    // FEATURE 3: Track Listening History (for Statistics)
    private fun trackListeningHistory(song: Song) {
        viewModelScope.launch {
            try {
                val history = ListeningHistory(
                    songId = song.id,
                    playedAt = System.currentTimeMillis(),
                    duration = 0, // Will be updated when song ends
                    completed = false
                )
                musicRepository.insertListeningHistory(history)
                Timber.d("Listening history tracked for: ${song.title}")
            } catch (e: Exception) {
                Timber.e(e, "Failed to track listening history")
            }
        }
    }

    // Core playback controls
    fun playSong(song: Song) {
        viewModelScope.launch {
            try {
                _playerState.value = _playerState.value.copy(currentSong = song)

                when (val result = youTubeRepository.getStreamUrl(song.youtubeId)) {
                    is Resource.Success -> {
                        val mediaItem = MediaItem.Builder()
                            .setUri(result.data)
                            .setMediaId(song.id)
                            .build()

                        mediaController?.setMediaItem(mediaItem)
                        mediaController?.prepare()
                        mediaController?.play()

                        // Save to library
                        musicRepository.insertSong(song)
                    }
                    is Resource.Error -> {
                        Timber.e("Failed to get stream URL: ${result.message}")
                    }
                    else -> {}
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to play song")
            }
        }
    }

    fun togglePlayPause() {
        mediaController?.let {
            if (it.isPlaying) {
                it.pause()
            } else {
                it.play()
            }
        }
    }

    fun skipToNext() {
        mediaController?.seekToNext()
    }

    fun skipToPrevious() {
        mediaController?.seekToPrevious()
    }

    fun seekTo(position: Long) {
        mediaController?.seekTo(position)
    }

    fun toggleShuffle() {
        val newShuffleState = !_playerState.value.shuffleEnabled
        _playerState.value = _playerState.value.copy(shuffleEnabled = newShuffleState)
        mediaController?.shuffleModeEnabled = newShuffleState
    }

    fun toggleRepeatMode() {
        val newMode = when (_playerState.value.repeatMode) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        _playerState.value = _playerState.value.copy(repeatMode = newMode)
        
        mediaController?.repeatMode = when (newMode) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
        }
    }

    fun getCurrentPosition(): Long {
        return mediaController?.currentPosition ?: 0L
    }

    private fun updateCurrentSongFromMediaItem() {
        // Update current song info when media item transitions
        val currentMediaItem = mediaController?.currentMediaItem
        val currentIndex = mediaController?.currentMediaItemIndex ?: 0
        
        _playerState.value = _playerState.value.copy(
            currentIndex = currentIndex,
            duration = mediaController?.duration ?: 0L
        )
    }

    override fun onCleared() {
        super.onCleared()
        
        // Release audio effects
        bassBoostEffect?.release()
        virtualizerEffect?.release()
        reverbEffect?.release()
        
        // Cancel sleep timer
        sleepTimerJob?.cancel()
        
        // Release media controller
        MediaController.releaseFuture(controllerFuture ?: return)
        
        Timber.d("MusicPlayerViewModel cleared")
    }
}

// Data classes for features
data class Bookmark(
    val id: Long = 0,
    val songId: String,
    val position: Long,
    val note: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class ListeningHistory(
    val id: Long = 0,
    val songId: String,
    val playedAt: Long,
    val duration: Long,
    val completed: Boolean
)
