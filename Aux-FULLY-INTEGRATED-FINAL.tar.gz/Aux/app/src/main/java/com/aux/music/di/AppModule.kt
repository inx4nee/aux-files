package com.aux.music.di

import android.content.Context
import androidx.room.Room
import com.aux.music.data.api.InnerTubeApi
import com.aux.music.data.local.AuxDatabase
import com.aux.music.data.local.DownloadDao
import com.aux.music.data.local.PlaylistDao
import com.aux.music.data.local.SongDao
import com.aux.music.data.repository.HybridMusicRepository
import com.aux.music.service.DiscordRichPresence
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt module for providing dependencies
 * Updated with InnerTube API and Discord Rich Presence
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideAuxDatabase(@ApplicationContext context: Context): AuxDatabase {
        return Room.databaseBuilder(
            context,
            AuxDatabase::class.java,
            "aux_database"
        ).build()
    }

    @Provides
    @Singleton
    fun provideSongDao(database: AuxDatabase): SongDao {
        return database.songDao()
    }

    @Provides
    @Singleton
    fun providePlaylistDao(database: AuxDatabase): PlaylistDao {
        return database.playlistDao()
    }

    @Provides
    @Singleton
    fun provideDownloadDao(database: AuxDatabase): DownloadDao {
        return database.downloadDao()
    }
    
    @Provides
    @Singleton
    fun provideInnerTubeApi(): InnerTubeApi {
        return InnerTubeApi()
    }
    
    @Provides
    @Singleton
    fun provideHybridMusicRepository(
        innerTubeApi: InnerTubeApi
    ): HybridMusicRepository {
        return HybridMusicRepository(innerTubeApi)
    }
    
    @Provides
    @Singleton
    fun provideDiscordRichPresence(
        @ApplicationContext context: Context
    ): DiscordRichPresence {
        return DiscordRichPresence(context)
    }
}
