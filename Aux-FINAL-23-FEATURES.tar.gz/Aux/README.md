# Aux - Music Streaming App (No Firebase Version)

Aux is a modern, ad-free music streaming and player app for Android that follows Google's Material 3 design guidelines. Built with Kotlin, Jetpack Compose, and NewPipe Extractor for YouTube integration.

**This version works 100% offline with no cloud services required!**

## ⚠️ Important Notice

This app is for **educational purposes only**. Downloading copyrighted content from YouTube may violate YouTube's Terms of Service and copyright laws in your jurisdiction. Use responsibly and at your own risk.

## ✨ Features

- 🎵 **Stream Music** - Search and stream music from YouTube
- 📥 **Download Songs** - Save songs for offline listening
- 📱 **Material 3 Design** - Beautiful, modern UI following latest design guidelines
- 🎨 **Dynamic Colors** - Adapts to your device's wallpaper (Android 12+)
- 🎯 **Clean Interface** - Ad-free, distraction-free experience
- 📚 **Library Management** - Organize your music in playlists
- 🔄 **Background Playback** - Continue listening while using other apps
- 🔀 **Shuffle & Repeat** - Full playback controls
- 🌙 **Dark Mode** - Automatic dark theme support
- 💾 **Local Storage** - All data stored on your device, no account needed

## 🏗️ Tech Stack

- **Language**: Kotlin
- **UI Framework**: Jetpack Compose with Material 3
- **Architecture**: MVVM (Model-View-ViewModel)
- **Dependency Injection**: Hilt
- **Database**: Room (local SQLite database)
- **Media Playback**: Media3 (ExoPlayer)
- **YouTube Integration**: NewPipe Extractor
- **Networking**: Retrofit, OkHttp
- **Image Loading**: Coil
- **Async**: Kotlin Coroutines & Flow

## 📋 Prerequisites

- Android Studio Hedgehog (2023.1.1) or later
- JDK 17 or later
- Android SDK 26 (Android 8.0) or higher
- **NO Firebase account needed!**
- **NO Google Services needed!**

## 🚀 Setup Instructions (3 Simple Steps!)

### 1. Open in Android Studio

1. Extract the Aux project folder
2. Open Android Studio
3. Select "Open an Existing Project"
4. Navigate to the Aux folder
5. Click "OK"

### 2. Sync Gradle

1. Click "Sync Now" when prompted
2. Wait for all dependencies to download (5-10 minutes first time)
3. Fix any errors that appear

### 3. Build and Run

1. Connect an Android device or start an emulator
2. Click the "Run" button (green play icon)
3. Select your device
4. Wait for the app to install and launch

**That's it! No Firebase setup, no google-services.json, no cloud configuration needed!**

## 📝 Usage

1. **Search for Music**
   - Go to the Search tab
   - Enter song name, artist, or keywords
   - Tap on a song to play or download

2. **Play Music**
   - Tap any song to start playback
   - Use the now playing card to control playback
   - Playback continues in the background

3. **Create Playlists**
   - Go to Library tab
   - Switch to Playlists
   - Tap the + button to create a new playlist

4. **Download Songs**
   - Tap the download icon on any song
   - Access downloaded songs in Library > Downloads

## 💾 Data Storage

**Everything is stored locally on your device:**
- Songs database (Room SQLite)
- Playlists
- Downloaded audio files
- App settings

**Your data is:**
- ✅ Private (never leaves your device)
- ✅ Offline-accessible
- ✅ Fast (no network delays)
- ✅ Under your control

## 🐛 Troubleshooting

### Build Errors
- Sync Gradle files: File > Sync Project with Gradle Files
- Clean build: Build > Clean Project
- Invalidate caches: File > Invalidate Caches > Restart

### NewPipe Issues
- NewPipe may break when YouTube updates
- Check for library updates on their GitHub

### App Crashes
- Check Logcat for errors
- Verify all permissions granted
- Try different device/emulator

## 🎯 Quick Start

```bash
# 1. Open Android Studio
# 2. File > Open > Select Aux folder
# 3. Wait for Gradle sync
# 4. Click Run button (▶️)
# 5. Done! No additional setup required!
```

---

**No Firebase = No Setup Hassle = Just Code and Run!** 🚀
