package com.aux.music.data.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

/**
 * Free Lyrics API - No API Key Required!
 * Source: https://lyricsovh.docs.apiary.io/
 */

data class LyricsResponse(
    val lyrics: String?
)

interface LyricsApi {
    @GET("v1/{artist}/{title}")
    suspend fun getLyrics(
        @Path("artist") artist: String,
        @Path("title") title: String
    ): LyricsResponse
}

object LyricsService {
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://api.lyrics.ovh/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val api: LyricsApi = retrofit.create(LyricsApi::class.java)
}

// Usage in ViewModel:
suspend fun fetchLyrics(song: Song): String? {
    return try {
        val response = LyricsService.api.getLyrics(
            artist = song.artist,
            title = song.title
        )
        response.lyrics
    } catch (e: Exception) {
        timber.log.Timber.e(e, "Failed to fetch lyrics")
        null
    }
}

// In NowPlayingScreen:
LaunchedEffect(currentSong) {
    currentSong?.let { song ->
        val lyrics = viewModel.fetchLyrics(song)
        if (lyrics != null) {
            lyricsText = lyrics
        }
    }
}
