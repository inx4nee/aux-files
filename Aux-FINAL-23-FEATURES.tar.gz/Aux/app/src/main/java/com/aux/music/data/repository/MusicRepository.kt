package com.aux.music.data.repository

import com.aux.music.data.local.PlaylistDao
import com.aux.music.data.local.SongDao
import com.aux.music.data.model.Playlist
import com.aux.music.data.model.PlaylistSongCrossRef
import com.aux.music.data.model.Song
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository for local music database operations
 */
@Singleton
class MusicRepository @Inject constructor(
    private val songDao: SongDao,
    private val playlistDao: PlaylistDao
) {

    // Song operations
    fun getAllSongs(): Flow<List<Song>> = songDao.getAllSongs()

    fun getDownloadedSongs(): Flow<List<Song>> = songDao.getDownloadedSongs()

    fun searchLocalSongs(query: String): Flow<List<Song>> = songDao.searchSongs(query)

    suspend fun getSongById(songId: String): Song? = songDao.getSongById(songId)

    suspend fun insertSong(song: Song) = songDao.insertSong(song)

    suspend fun insertSongs(songs: List<Song>) = songDao.insertSongs(songs)

    suspend fun updateSong(song: Song) = songDao.updateSong(song)

    suspend fun deleteSong(song: Song) = songDao.deleteSong(song)

    suspend fun deleteSongById(songId: String) = songDao.deleteSongById(songId)

    suspend fun getSongCount(): Int = songDao.getSongCount()

    // Playlist operations
    fun getAllPlaylists(): Flow<List<Playlist>> = playlistDao.getAllPlaylists()

    suspend fun getPlaylistById(playlistId: Long): Playlist? = playlistDao.getPlaylistById(playlistId)

    suspend fun createPlaylist(playlist: Playlist): Long = playlistDao.insertPlaylist(playlist)

    suspend fun updatePlaylist(playlist: Playlist) = playlistDao.updatePlaylist(playlist)

    suspend fun deletePlaylist(playlist: Playlist) = playlistDao.deletePlaylist(playlist)

    fun getSongsInPlaylist(playlistId: Long): Flow<List<Song>> = 
        playlistDao.getSongsInPlaylist(playlistId)

    suspend fun addSongToPlaylist(playlistId: Long, songId: String) {
        val count = playlistDao.getSongCountInPlaylist(playlistId)
        playlistDao.insertPlaylistSongCrossRef(
            PlaylistSongCrossRef(
                playlistId = playlistId,
                songId = songId,
                position = count
            )
        )
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: String) {
        playlistDao.deletePlaylistSongCrossRef(
            PlaylistSongCrossRef(
                playlistId = playlistId,
                songId = songId
            )
        )
    }

    suspend fun clearPlaylist(playlistId: Long) {
        playlistDao.deleteAllSongsFromPlaylist(playlistId)
    }
}
