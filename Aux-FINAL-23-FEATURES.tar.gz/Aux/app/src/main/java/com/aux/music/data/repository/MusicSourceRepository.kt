package com.aux.music.data.repository

import com.aux.music.data.model.SearchResult
import com.aux.music.data.model.Song
import com.aux.music.util.Resource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Unified repository that handles both YouTube and SoundCloud
 * Allows users to switch between music sources
 */
@Singleton
class MusicSourceRepository @Inject constructor(
    private val youTubeRepository: YouTubeRepositoryOptimized,
    private val soundCloudRepository: SoundCloudRepository
) {

    // Current selected source
    private val _currentSource = MutableStateFlow(MusicSource.YOUTUBE)
    val currentSource: StateFlow<MusicSource> = _currentSource.asStateFlow()

    /**
     * Switch between YouTube and SoundCloud
     */
    fun setMusicSource(source: MusicSource) {
        _currentSource.value = source
        Timber.d("Music source switched to: $source")
    }

    /**
     * Search songs from current source
     */
    suspend fun searchSongs(
        query: String,
        pageToken: String? = null
    ): Resource<SearchResult> {
        return when (_currentSource.value) {
            MusicSource.YOUTUBE -> youTubeRepository.searchSongs(query, pageToken)
            MusicSource.SOUNDCLOUD -> soundCloudRepository.searchSongs(query, pageToken)
        }
    }

    /**
     * Get stream URL from appropriate source
     */
    suspend fun getStreamUrl(song: Song): Resource<String> {
        return when (song.source) {
            MusicSource.YOUTUBE -> youTubeRepository.getStreamUrl(song.youtubeId)
            MusicSource.SOUNDCLOUD -> soundCloudRepository.getStreamUrl(song.soundCloudId ?: "")
        }
    }

    /**
     * Get trending music from current source
     */
    suspend fun getTrendingMusic(): Resource<List<Song>> {
        return when (_currentSource.value) {
            MusicSource.YOUTUBE -> youTubeRepository.getTrendingMusic()
            MusicSource.SOUNDCLOUD -> soundCloudRepository.getTrendingMusic()
        }
    }

    /**
     * Clear all caches
     */
    fun clearAllCaches() {
        youTubeRepository.clearCache()
        soundCloudRepository.clearCache()
    }

    /**
     * Get source display name
     */
    fun getSourceName(): String {
        return when (_currentSource.value) {
            MusicSource.YOUTUBE -> "YouTube"
            MusicSource.SOUNDCLOUD -> "SoundCloud"
        }
    }

    /**
     * Get source icon
     */
    fun getSourceIcon(): SourceIcon {
        return when (_currentSource.value) {
            MusicSource.YOUTUBE -> SourceIcon.YOUTUBE
            MusicSource.SOUNDCLOUD -> SourceIcon.SOUNDCLOUD
        }
    }
}

enum class SourceIcon {
    YOUTUBE,
    SOUNDCLOUD
}
