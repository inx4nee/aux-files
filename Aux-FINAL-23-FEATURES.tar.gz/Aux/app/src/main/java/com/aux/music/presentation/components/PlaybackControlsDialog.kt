package com.aux.music.presentation.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Advanced playback controls dialog with speed, pitch, and audio effects
 */
@Composable
fun PlaybackControlsDialog(
    onDismiss: () -> Unit,
    currentSpeed: Float = 1.0f,
    currentPitch: Float = 1.0f,
    onSpeedChange: (Float) -> Unit = {},
    onPitchChange: (Float) -> Unit = {},
    onResetDefaults: () -> Unit = {}
) {
    var speed by remember { mutableStateOf(currentSpeed) }
    var pitch by remember { mutableStateOf(currentPitch) }
    
    // Audio Effects State
    var bassBoost by remember { mutableStateOf(0f) }
    var virtualizer by remember { mutableStateOf(0f) }
    var reverb by remember { mutableStateOf(0f) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Tune,
                contentDescription = null,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text("Playback Controls")
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Speed Control
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Speed",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "${String.format("%.2f", speed)}x",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = speed,
                        onValueChange = { 
                            speed = it
                            onSpeedChange(it)
                        },
                        valueRange = 0.5f..2.0f,
                        steps = 29
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("0.5x", style = MaterialTheme.typography.bodySmall)
                        Text("1.0x", style = MaterialTheme.typography.bodySmall)
                        Text("2.0x", style = MaterialTheme.typography.bodySmall)
                    }
                }

                Divider()

                // Pitch Control
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Pitch",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "${String.format("%.2f", pitch)}x",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = pitch,
                        onValueChange = { 
                            pitch = it
                            onPitchChange(it)
                        },
                        valueRange = 0.5f..2.0f,
                        steps = 29
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("0.5x", style = MaterialTheme.typography.bodySmall)
                        Text("1.0x", style = MaterialTheme.typography.bodySmall)
                        Text("2.0x", style = MaterialTheme.typography.bodySmall)
                    )
                }

                Divider()

                // Audio Effects
                Text(
                    text = "Audio Effects",
                    style = MaterialTheme.typography.titleMedium
                )

                // Bass Boost
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Bass Boost",
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                        Text(
                            text = "${(bassBoost * 100).toInt()}%",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Slider(
                        value = bassBoost,
                        onValueChange = { bassBoost = it },
                        valueRange = 0f..1f
                    )
                }

                // Virtualizer (3D Effect)
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Headset,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "3D Surround",
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                        Text(
                            text = "${(virtualizer * 100).toInt()}%",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Slider(
                        value = virtualizer,
                        onValueChange = { virtualizer = it },
                        valueRange = 0f..1f
                    )
                }

                // Reverb
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Waves,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Reverb",
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                        Text(
                            text = "${(reverb * 100).toInt()}%",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Slider(
                        value = reverb,
                        onValueChange = { reverb = it },
                        valueRange = 0f..1f
                    )
                }
            }
        },
        confirmButton = {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(
                    onClick = {
                        speed = 1.0f
                        pitch = 1.0f
                        bassBoost = 0f
                        virtualizer = 0f
                        reverb = 0f
                        onResetDefaults()
                    }
                ) {
                    Text("Reset")
                }
                TextButton(onClick = onDismiss) {
                    Text("Done")
                }
            }
        }
    )
}

/**
 * Quality Selector Dialog
 */
@Composable
fun QualitySelector Dialog(
    onDismiss: () -> Unit,
    currentQuality: String = "High (256kbps)",
    onQualitySelected: (String) -> Unit = {}
) {
    val qualities = listOf(
        "Low (128kbps)" to "Saves data, lower quality",
        "Medium (192kbps)" to "Balanced quality and size",
        "High (256kbps)" to "Better quality, more data",
        "Very High (320kbps)" to "Best quality, most data"
    )
    var selectedQuality by remember { mutableStateOf(currentQuality) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.HighQuality,
                contentDescription = null
            )
        },
        title = {
            Text("Audio Quality")
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                qualities.forEach { (quality, description) ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedQuality == quality)
                                MaterialTheme.colorScheme.primaryContainer
                            else
                                MaterialTheme.colorScheme.surfaceVariant
                        ),
                        onClick = { selectedQuality = quality }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = quality,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Text(
                                    text = description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (selectedQuality == quality) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onQualitySelected(selectedQuality)
                    onDismiss()
                }
            ) {
                Text("Apply")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
