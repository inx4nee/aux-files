package com.aux.music

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import dagger.hilt.android.HiltAndroidApp
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.downloader.Downloader
import timber.log.Timber

/**
 * Main Application class for Aux
 * Initializes Hilt, NewPipe Extractor, Timber, and notification channels
 */
@HiltAndroidApp
class AuxApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        
        // Initialize Timber for logging
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        Timber.d("Aux Application starting...")
        
        // Initialize NewPipe Extractor
        initializeNewPipeExtractor()
        
        // Create notification channels for Android O and above
        createNotificationChannels()
        
        Timber.d("Aux Application initialized successfully")
    }

    private fun initializeNewPipeExtractor() {
        // Initialize NewPipe with custom downloader
        NewPipe.init(DownloaderImpl.getInstance())
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            // Music playback notification channel
            val playbackChannel = NotificationChannel(
                PLAYBACK_CHANNEL_ID,
                "Music Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows currently playing music"
                setShowBadge(false)
            }

            // Download notification channel
            val downloadChannel = NotificationChannel(
                DOWNLOAD_CHANNEL_ID,
                "Downloads",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows download progress"
                setShowBadge(true)
            }

            notificationManager.createNotificationChannel(playbackChannel)
            notificationManager.createNotificationChannel(downloadChannel)
        }
    }

    companion object {
        const val PLAYBACK_CHANNEL_ID = "music_playback_channel"
        const val DOWNLOAD_CHANNEL_ID = "download_channel"
    }
}
