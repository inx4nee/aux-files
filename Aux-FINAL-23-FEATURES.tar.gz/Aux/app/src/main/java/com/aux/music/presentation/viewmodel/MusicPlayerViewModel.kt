package com.aux.music.presentation.viewmodel

import android.content.ComponentName
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.aux.music.data.model.PlayerState
import com.aux.music.data.model.RepeatMode
import com.aux.music.data.model.Song
import com.aux.music.data.repository.YouTubeRepository
import com.aux.music.service.MusicPlayerService
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for managing music player state and controls
 */
@HiltViewModel
class MusicPlayerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val youTubeRepository: YouTubeRepository
) : ViewModel() {

    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    private var mediaController: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    init {
        initializeMediaController()
    }

    private fun initializeMediaController() {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, MusicPlayerService::class.java)
        )

        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture?.addListener(
            {
                mediaController = controllerFuture?.get()
                setupPlayerListener()
            },
            MoreExecutors.directExecutor()
        )
    }

    private fun setupPlayerListener() {
        mediaController?.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _playerState.value = _playerState.value.copy(isPlaying = isPlaying)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _playerState.value = _playerState.value.copy(
                        duration = mediaController?.duration ?: 0L
                    )
                }
            }
        })
    }

    fun playSong(song: Song) {
        viewModelScope.launch {
            // Get stream URL
            val result = youTubeRepository.getStreamUrl(song.youtubeId)
            result.onSuccess { streamUrl ->
                val mediaItem = MediaItem.Builder()
                    .setUri(streamUrl)
                    .setMediaId(song.id)
                    .build()

                mediaController?.setMediaItem(mediaItem)
                mediaController?.prepare()
                mediaController?.play()

                _playerState.value = _playerState.value.copy(
                    currentSong = song,
                    isPlaying = true
                )
            }
        }
    }

    fun playQueue(songs: List<Song>, startIndex: Int = 0) {
        viewModelScope.launch {
            if (songs.isEmpty()) return@launch

            val mediaItems = mutableListOf<MediaItem>()
            
            // Load stream URLs for all songs
            songs.forEach { song ->
                val result = youTubeRepository.getStreamUrl(song.youtubeId)
                result.onSuccess { streamUrl ->
                    mediaItems.add(
                        MediaItem.Builder()
                            .setUri(streamUrl)
                            .setMediaId(song.id)
                            .build()
                    )
                }
            }

            mediaController?.setMediaItems(mediaItems, startIndex, 0)
            mediaController?.prepare()
            mediaController?.play()

            _playerState.value = _playerState.value.copy(
                queue = songs,
                currentIndex = startIndex,
                currentSong = songs[startIndex],
                isPlaying = true
            )
        }
    }

    fun togglePlayPause() {
        mediaController?.let {
            if (it.isPlaying) {
                it.pause()
            } else {
                it.play()
            }
        }
    }

    fun skipToNext() {
        mediaController?.seekToNext()
        val newIndex = (_playerState.value.currentIndex + 1) % _playerState.value.queue.size
        _playerState.value = _playerState.value.copy(
            currentIndex = newIndex,
            currentSong = _playerState.value.queue.getOrNull(newIndex)
        )
    }

    fun skipToPrevious() {
        mediaController?.seekToPrevious()
        val newIndex = (_playerState.value.currentIndex - 1).coerceAtLeast(0)
        _playerState.value = _playerState.value.copy(
            currentIndex = newIndex,
            currentSong = _playerState.value.queue.getOrNull(newIndex)
        )
    }

    fun seekTo(position: Long) {
        mediaController?.seekTo(position)
        _playerState.value = _playerState.value.copy(currentPosition = position)
    }

    fun toggleShuffle() {
        val newShuffleState = !_playerState.value.shuffleEnabled
        mediaController?.shuffleModeEnabled = newShuffleState
        _playerState.value = _playerState.value.copy(shuffleEnabled = newShuffleState)
    }

    fun toggleRepeatMode() {
        val newRepeatMode = when (_playerState.value.repeatMode) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }

        val playerRepeatMode = when (newRepeatMode) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
        }

        mediaController?.repeatMode = playerRepeatMode
        _playerState.value = _playerState.value.copy(repeatMode = newRepeatMode)
    }

    fun getCurrentPosition(): Long {
        return mediaController?.currentPosition ?: 0L
    }

    override fun onCleared() {
        super.onCleared()
        mediaController?.release()
        controllerFuture?.let {
            MediaController.releaseFuture(it)
        }
    }
}
